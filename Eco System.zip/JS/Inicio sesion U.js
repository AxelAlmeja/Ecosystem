const container = document.querySelector('.container');
const LoginLink = document.querySelector('.SignInLink');
const RegisterLink = document.querySelector('.SignUpLink');

const loginForm = document.querySelector('.form-box.Login form');
const loginUsernameInput = document.getElementById('login-username');
const loginPasswordInput = document.getElementById('login-password');

const registerForm = document.querySelector('.form-box.Register form');
const registerUsernameInput = document.getElementById('register-username');
const registerEmailInput = document.getElementById('register-email');
const registerPasswordInput = document.getElementById('register-password');

RegisterLink.addEventListener('click', () => {
    container.classList.add('active');
})

LoginLink.addEventListener('click', () => {
    container.classList.remove('active');
})

registerForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const username = registerUsernameInput.value.trim();
    const email = registerEmailInput.value.trim();
    const password = registerPasswordInput.value.trim();

    if (!username || !email || !password) {
        alert('Por favor, completa todos los campos.');
        return;
    }

    if (!/^\d{14}$/.test(username)) {
        alert('El número de control debe contener exactamente 14 dígitos.');
        return;
    }

    let users = JSON.parse(localStorage.getItem('users')) || {};

    if (users[username]) {
        alert('❌ Error de registro: El número de control ya está registrado.');
        return;
    }

    users[username] = {
        username: username,
        email: email,
        password: password
    };

    localStorage.setItem('users', JSON.stringify(users));

    alert('✅ Registro exitoso. Ahora puedes iniciar sesión.');

    registerForm.reset();
    container.classList.remove('active');
});

loginForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const username = loginUsernameInput.value.trim();
    const password = loginPasswordInput.value.trim();

    if (!username || !password) {
        alert('Por favor, ingresa tu No. control y Contraseña.');
        return;
    }


    if (!/^\d{14}$/.test(username)) {
        alert('El número de control debe contener exactamente 14 dígitos.');
        return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || {};
    const user = users[username];

    if (user && user.password === password) {
        localStorage.setItem('loggedInUser', username);
        localStorage.setItem('role', 'user');

        loginForm.reset();
        window.location.href = 'comunidad.html';
    } else {
        alert('❌ Error de inicio de sesión: No. control o Contraseña incorrectos.');
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');

    togglePasswordIcons.forEach(icon => {
        icon.setAttribute('color', '#2A5B5F');

        icon.addEventListener('click', () => {
            const targetId = icon.getAttribute('data-target');
            const passwordInput = document.getElementById(targetId);

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.setAttribute('name', 'show');
            } else {
                passwordInput.type = 'password';
                icon.setAttribute('name', 'hide');
            }
        });
    });
});