document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("lista-ideas-guardadas");
  const form = document.getElementById("formulario-ideas");
  const input = document.getElementById("idea-texto");
  const borrarBtn = document.getElementById("borrar-ideas-btn");
  const contador = document.getElementById("contador-ideas");
  const feedback = document.getElementById("mensaje-feedback");

  const role = localStorage.getItem("role");
  const loggedInUser = localStorage.getItem("loggedInUser");

  // === NUEVOS ELEMENTOS PARA GALERÍA ===
  const formularioImagenes = document.getElementById("formulario-imagenes");
  const imagenArchivoInput = document.getElementById("imagen-archivo");
  const imagenDescripcionInput = document.getElementById("imagen-descripcion");
  const mensajeImagenFeedback = document.getElementById("mensaje-imagen-feedback");
  const galeriaAprobadas = document.getElementById("galeria-imagenes-aprobadas");

  // === ELEMENTOS PARA AVISOS ===
  const avisosSection = document.querySelector('.avisos');
  const avisosContainer = avisosSection ? avisosSection.querySelector('.inner-content') : null;
  // =====================================

  if (borrarBtn) {
    if (role !== "admin") {
      borrarBtn.classList.add("oculto");
    } else {
      borrarBtn.classList.remove("oculto");
    }
  }

  const obtenerIdeas = () => JSON.parse(localStorage.getItem("ideasVerdes")) || [];
  const guardarIdeas = ideas => localStorage.setItem("ideasVerdes", JSON.stringify(ideas));
  const obtenerVotos = () => JSON.parse(localStorage.getItem("votosUsuario")) || {};
  const guardarVotos = votos => localStorage.setItem("votosUsuario", JSON.stringify(votos));

  // Funciones para la Galería Aprobada (clave: galeriaFotos)
  const GALERIA_KEY = 'galeriaFotos';
  const getGaleria = () => JSON.parse(localStorage.getItem(GALERIA_KEY)) || {};
  const saveGaleria = (fotos) => localStorage.setItem(GALERIA_KEY, JSON.stringify(fotos));

  // Funciones para Fotos Pendientes (clave: fotosPendientes) - CRUCIAL PARA EL ADMIN
  const PENDING_KEY = 'fotosPendientes';
  const getFotosPendientes = () => JSON.parse(localStorage.getItem(PENDING_KEY)) || {};
  const saveFotosPendientes = (fotos) => localStorage.setItem(PENDING_KEY, JSON.stringify(fotos));


  function mostrarFeedback(mensaje, tipo = 'success') {
    feedback.textContent = mensaje;
    feedback.className = `mensaje-feedback ${tipo}`;
    feedback.classList.remove('oculto');
    setTimeout(() => {
      feedback.classList.add('oculto');
    }, 3000);
  }

  // === FUNCIÓN DE FEEDBACK PARA IMAGENES ===
  function mostrarFeedbackImagen(mensaje, tipo = 'success') {
    mensajeImagenFeedback.textContent = mensaje;
    mensajeImagenFeedback.className = `mensaje-feedback ${tipo}`;
    mensajeImagenFeedback.classList.remove('oculto');
    setTimeout(() => {
      mensajeImagenFeedback.classList.add('oculto');
    }, 3000);
  }

  function mostrarIdeas() {
    const ideas = obtenerIdeas();
    const votosUsuario = obtenerVotos();
    lista.innerHTML = "";

    if (ideas.length === 0) {
      lista.innerHTML = `<li style="border-left: 5px solid #ccc; background-color: rgba(255, 255, 255, 0.1); color: #444; text-align: center;">No hay ideas aún. ¡Sé el primero en proponer una!</li>`;
      contador.textContent = `Total de ideas: 0`;
    } else {
      ideas.sort((a, b) => b.votos - a.votos || new Date(b.fecha) - new Date(a.fecha));

      ideas.forEach((idea) => {
        const li = document.createElement("li");
        const haVotado = votosUsuario[loggedInUser] && votosUsuario[loggedInUser][idea.id];

        li.innerHTML = `
          <div class="idea-content">
            ${idea.texto}
            <span style="font-size:0.8em; color: #777; display:block;">(${new Date(idea.fecha).toLocaleDateString('es-MX')})</span>
          </div>
          <div class="votos-container">
            <span class="votos-contador">${idea.votos}</span>
            <button class="voto-btn" data-id="${idea.id}" ${!loggedInUser || haVotado ? 'disabled' : ''}>
              ${haVotado ? '👍' : '⬆️'}
            </button>
          </div>
        `;
        lista.appendChild(li);
      });
      contador.textContent = `Total de ideas: ${ideas.length}`;
    }
  }

  // === FUNCIÓN PARA ELIMINAR UNA IMAGEN INDIVIDUAL (ADMIN) ===
  function borrarImagenIndividual(id) {
    if (role !== "admin" || !confirm(`⚠️ ¿Estás seguro de que quieres eliminar la imagen con ID: ${id}?\nEsta acción es IRREVERSIBLE.`)) {
      return;
    }

    let galeria = getGaleria();
    
    // El objeto usa el ID como clave, así que eliminamos la propiedad
    if (galeria[id]) {
      delete galeria[id]; 
      saveGaleria(galeria);
      mostrarGaleriaAprobadas(); // Recargar la galería
      mostrarFeedbackImagen("✅ Imagen eliminada con éxito.", 'info');
    } else {
      mostrarFeedbackImagen("❌ Error: No se encontró la imagen con ese ID.", 'error');
    }
  }
  // =================================================================

  // === FUNCIÓN PARA MOSTRAR LA GALERÍA CON CARRUSEL (MODIFICADA) ===
  function mostrarGaleriaAprobadas() {
    const fotosAprobadas = Object.values(getGaleria());

    if (!galeriaAprobadas) return;

    if (fotosAprobadas.length === 0) {
      galeriaAprobadas.innerHTML = '<p style="text-align: center; color: #777;">Aún no hay imágenes aprobadas en la galería.</p>';
      return;
    }

    // 1. Insertar todas las fotos en la galería (ocultas por defecto)
    galeriaAprobadas.innerHTML = ''; // Limpiar el mensaje de carga
    // Ordenar por fecha o timestamp, más reciente primero
    fotosAprobadas.sort((a, b) => new Date(b.timestamp || b.fechaPublicacion) - new Date(a.timestamp || a.fechaPublicacion)); 
    
    fotosAprobadas.forEach((foto, index) => {
      const fotoId = foto.id; // Asumimos que la foto tiene un ID
      const div = document.createElement('div');
      div.classList.add('galeria-item');
      if (index === 0) {
        div.classList.add('active'); // La primera foto está activa al inicio
      }
      // Usamos foto.imageDataUrl o foto.base64 (por si acaso)
      div.innerHTML = `
        <img src="${foto.imageDataUrl || foto.base64}" alt="${foto.descripcion}">
        <div class="galeria-overlay">
          <p class="galeria-desc">${foto.descripcion}</p>
          <p class="galeria-meta">Subida por: ${foto.controlUsuario || foto.usuario || 'Desconocido'} | Publicada: ${foto.fechaPublicacion || new Date(foto.timestamp).toLocaleDateString()}</p>
          
          ${role === 'admin' ? 
            `<button class="borrar-imagen-individual-btn" data-id="${fotoId}">
               ❌ Eliminar Imagen
             </button>` 
            : ''}
          </div>
      `;
      galeriaAprobadas.appendChild(div);
    });

    // 2. Lógica del Carrusel con Fade y Event Listener para el borrado
    const items = galeriaAprobadas.querySelectorAll('.galeria-item');
    let currentIndex = 0;
    const totalItems = items.length;

    if (totalItems > 1) {
      setInterval(() => {
        // Desactivar el elemento actual
        items[currentIndex].classList.remove('active');

        // Mover al siguiente índice
        currentIndex = (currentIndex + 1) % totalItems;

        // Activar el nuevo elemento
        items[currentIndex].classList.add('active');

      }, 5000); // 5 segundos por foto
    }
    
    // Listener para los botones de eliminación individual
    if (role === 'admin') {
        galeriaAprobadas.querySelectorAll('.borrar-imagen-individual-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const idToDelete = e.target.getAttribute('data-id');
                borrarImagenIndividual(idToDelete);
            });
        });
    }
  }
  // ==============================================================


  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      if (!loggedInUser) {
        alert("Debes iniciar sesión para enviar una propuesta.");
        return;
      }

      const ideaTexto = input.value.trim();
      if (ideaTexto === "") return;

      const nuevaIdea = {
        id: Date.now().toString(),
        texto: ideaTexto,
        votos: 0,
        fecha: new Date().toISOString(),
        usuario: loggedInUser
      };

      const ideas = obtenerIdeas();
      ideas.push(nuevaIdea);
      guardarIdeas(ideas);
      input.value = "";
      mostrarIdeas();
      mostrarFeedback("¡Idea enviada! Gracias por tu propuesta.");
    });
  }

  if (borrarBtn) {
    borrarBtn.addEventListener("click", () => {
      if (role === "admin" && confirm("¿Estás seguro de que quieres borrar TODAS las ideas de la comunidad?")) {
        localStorage.removeItem("ideasVerdes");
        localStorage.removeItem("votosUsuario");
        mostrarIdeas();
        mostrarFeedback("Todas las ideas y votos han sido borrados por el administrador.", 'info');
      }
    });
  }

  lista.addEventListener("click", (e) => {
    if (e.target.classList.contains("voto-btn") && loggedInUser) {
      const boton = e.target;
      const ideaId = boton.getAttribute("data-id");

      let ideas = obtenerIdeas();
      let votosUsuario = obtenerVotos();

      if (!votosUsuario[loggedInUser]) {
        votosUsuario[loggedInUser] = {};
      }

      if (!votosUsuario[loggedInUser][ideaId]) {
        const ideaIndex = ideas.findIndex(i => i.id === ideaId);
        if (ideaIndex !== -1) {
          ideas[ideaIndex].votos += 1;
          votosUsuario[loggedInUser][ideaId] = true;
          guardarIdeas(ideas);
          guardarVotos(votosUsuario);

          mostrarIdeas();
        }
      }
    }
  });


  // === LÓGICA DE SUBIDA DE IMÁGENES (CORREGIDA PARA EL ADMIN) ===
  if (formularioImagenes) {
    formularioImagenes.addEventListener("submit", (e) => {
      e.preventDefault();

      if (!loggedInUser) {
        mostrarFeedbackImagen("Debes iniciar sesión para subir una foto.", 'error');
        return;
      }

      const file = imagenArchivoInput.files[0];
      const descripcion = imagenDescripcionInput.value.trim();

      if (!file || descripcion === "") {
        mostrarFeedbackImagen("Por favor, selecciona un archivo de imagen y añade una descripción.", 'error');
        return;
      }

      if (!file.type.startsWith('image/')) {
        mostrarFeedbackImagen("El archivo debe ser una imagen válida.", 'error');
        return;
      }

      const reader = new FileReader();

      reader.onload = function (event) {
        const id = Date.now().toString(); // Usamos ID de timestamp
        const fotosPendientes = getFotosPendientes(); // Lee de 'fotosPendientes'
        
        // Almacenar como objeto, como espera administración.js
        fotosPendientes[id] = {
            id: id,
            imageDataUrl: event.target.result, 
            descripcion: descripcion,
            usuario: loggedInUser,
            timestamp: new Date().toISOString(),
            status: 'pendiente', 
            fileName: file.name
        };

        saveFotosPendientes(fotosPendientes); // Guarda en 'fotosPendientes'
        formularioImagenes.reset();
        mostrarFeedbackImagen("¡Foto enviada! Estará visible en la galería una vez que un administrador la apruebe.", 'success');
      };

      reader.onerror = function (error) {
        console.error("Error al leer el archivo:", error);
        mostrarFeedbackImagen("Ocurrió un error al cargar la imagen. Intenta de nuevo.", 'error');
      };

      // Convertir el archivo a Base64
      reader.readAsDataURL(file);
    });
  }
  // ======================================


  // === FUNCIONALIDAD PARA FILTRAR AVISOS ===
  if (avisosSection && avisosContainer) {
    // 1. Crear el contenedor y el select del filtro
    const contenedorFiltros = document.createElement('div');
    contenedorFiltros.className = 'contenedor-filtros';
    contenedorFiltros.innerHTML = `
      <select id="filtroAvisos" class="selector-filtro">
        <option value="todos">Mostrar Todos los Avisos</option>
        <option value="grupal">Actividades de Grupo</option>
        <option value="intergrupal">Actividades de Varios Grupos</option>
        <option value="fuera">Actividades Fuera del Plantel</option>
      </select>
    `;

    // 2. Insertar los filtros después del H2 de la sección
    const h2Avisos = avisosContainer.querySelector('h2');
    if (h2Avisos) {
      avisosContainer.insertBefore(contenedorFiltros, h2Avisos.nextSibling);
    } else {
      avisosContainer.prepend(contenedorFiltros);
    }


    const filtroSelect = document.getElementById('filtroAvisos');
    const avisos = avisosContainer.querySelectorAll('.aviso');

    // 3. Aplicar transición al inicio
    avisos.forEach(aviso => {
      aviso.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    });

    // 4. Lógica de filtrado
    filtroSelect.addEventListener('change', (event) => {
      const filtroSeleccionado = event.target.value;

      avisos.forEach(aviso => {
        const tipoAviso = aviso.getAttribute('data-tipo');

        if (filtroSeleccionado === 'todos' || filtroSeleccionado === tipoAviso) {
          // Mostrar el aviso
          aviso.style.display = 'flex';
          setTimeout(() => aviso.style.opacity = '1', 10);
        } else {
          // Ocultar el aviso
          aviso.style.opacity = '0';
          // Espera a que la transición termine para cambiar display: none
          setTimeout(() => aviso.style.display = 'none', 300);
        }
      });
    });
  }
  // ====================================================

  mostrarIdeas();
  // Se llama a la función de galería consolidada
  mostrarGaleriaAprobadas(); 


  /* --- CARRUSEL DE DÍAS IMPORTANTES --- */
  const carruselDias = document.getElementById('carrusel-dias');
  if (carruselDias) {
    const items = carruselDias.querySelectorAll('.dia-importante-item');
    let indiceActual = 0;
    const totalItems = items.length;

    if (totalItems > 1) {
      // Simulación de carrusel con scroll automático si se necesita
      setInterval(() => {
        indiceActual = (indiceActual + 1) % totalItems;
        const scrollAmount = items[indiceActual].offsetLeft - carruselDias.offsetLeft;
        carruselDias.scrollTo({
          left: scrollAmount,
          behavior: 'smooth'
        });
      }, 4000);
    }
  }


  generarReporteMensual();
});


// --- FUNCIONES PARA REPORTE DE RECOLECCIÓN DE TAPAS (Fuera del DOMContentLoaded) ---
function obtenerRecolecciones() {
  const recoleccionesJSON = localStorage.getItem('recoleccionesTapas') || '[]';
  return JSON.parse(recoleccionesJSON);
}

function generarReporteMensual() {
  const contenedorReporte = document.getElementById('reporte-resultados');
  const recolecciones = obtenerRecolecciones();

  if (!contenedorReporte) {
    return;
  }

  if (recolecciones.length === 0) {
    contenedorReporte.innerHTML = '<p style="color: #FFC300;">Todavía no hay registros de recolección de tapas. ¡Empiecen a recolectar!</p>';
    return;
  }

  let totalTapas = 0;
  const acumuladoPorGrupo = {};

  recolecciones.forEach(rec => {
    const cantidad = parseInt(rec.cantidad, 10);
    if (isNaN(cantidad) || cantidad <= 0) return;

    totalTapas += cantidad;

    const clave = `${rec.especialidad}|${rec.grupo}|${rec.turno}`;

    if (!acumuladoPorGrupo[clave]) {
      acumuladoPorGrupo[clave] = {
        especialidad: rec.especialidad,
        grupo: rec.grupo,
        turno: rec.turno,
        total: 0
      };
    }
    acumuladoPorGrupo[clave].total += cantidad;
  });

  let campeon = null;
  let maxTapas = -1;

  for (const clave in acumuladoPorGrupo) {
    if (acumuladoPorGrupo[clave].total > maxTapas) {
      maxTapas = acumuladoPorGrupo[clave].total;
      campeon = acumuladoPorGrupo[clave];
    }
  }

  let reporteHTML = `
    <p style="font-size: 1.3em;">Total Recolectado en el Periodo:</p>
    <p><span class="total-tapas">${totalTapas.toLocaleString('es-MX')}</span> Tapas</p>
  `;

  if (campeon) {
    reporteHTML += `
      <div class="reporte-destacado">
        <h3>🥇 ¡El Mayor Contribuyente!</h3>
        <p>La combinación más destacada es:</p>
        <p><strong>Especialidad:</strong> <strong>${campeon.especialidad}</strong></p>
        <p><strong>Grupo:</strong> <strong>${campeon.grupo}</strong></p>
        <p><strong>Turno:</strong> <strong>${campeon.turno}</strong></p>
        <p>Con un impresionante total de <strong>${campeon.total.toLocaleString('es-MX')} tapas</strong>.</p>
      </div>
    `;
  }

  contenedorReporte.innerHTML = reporteHTML;
}