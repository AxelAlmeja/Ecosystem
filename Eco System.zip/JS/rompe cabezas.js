document.addEventListener('DOMContentLoaded', () => {
    const puzzle = document.getElementById("puzzle");
    const seleccionDificultad = document.getElementById("seleccion-dificultad");
    const infoContenedor = document.getElementById("info-contenedor");
    const movimientosDisplay = document.getElementById("movimientos");
    const btnRendirse = document.getElementById("btn-rendirse");
    const mensajeFinalOverlay = document.getElementById("mensaje-final-overlay");
    const tituloFinal = document.getElementById("titulo-final");
    const progresoFinalDisplay = document.getElementById("progreso-final");
    const movimientosFinalDisplay = document.getElementById("movimientos-final");
    const minimoMovimientosDisplay = document.getElementById("minimo-movimientos");
    const reiniciarJuegoBtn = document.getElementById("reiniciar-juego");
    const botonesDificultad = document.querySelectorAll('#opciones-dificultad button');

    const imgURL = "IMG/rompecabezas.png";
    let pieces = [];
    let gridSize = 3;
    let tileSize = 150;
    let moves = 0;
    let CORRECT_ORDER = [];

    function iniciarJuego() {
        moves = 0;
        actualizarDisplay();

        if (gridSize === 3) {
            tileSize = 150;
            puzzle.style.width = '450px';
            puzzle.style.height = '450px';
            puzzle.style.gridTemplateColumns = 'repeat(3, 1fr)';
            puzzle.style.gridTemplateRows = 'repeat(3, 1fr)';
        } else if (gridSize === 4) {
            tileSize = 112.5;
            puzzle.style.width = '450px';
            puzzle.style.height = '450px';
            puzzle.style.gridTemplateColumns = 'repeat(4, 1fr)';
            puzzle.style.gridTemplateRows = 'repeat(4, 1fr)';
        }

        const totalPieces = gridSize * gridSize;
        CORRECT_ORDER = Array.from({ length: totalPieces }, (_, i) => i);

        pieces = crearPiezas(totalPieces);

        let shuffledPieces = [];
        let isSolvable = false;

        while (!isSolvable) {
            shuffledPieces = barajarPiezas(pieces.slice(0, totalPieces - 1));
            shuffledPieces.push(pieces[totalPieces - 1]);
            isSolvable = true;
        }

        pieces = shuffledPieces;
        dibujarTablero();

        seleccionDificultad.classList.add('oculto');
        infoContenedor.classList.remove('oculto');
        puzzle.classList.remove('oculto');
        mensajeFinalOverlay.classList.add('oculto');
    }

    function crearPiezas(totalPieces) {
        let newPieces = [];
        for (let i = 0; i < totalPieces; i++) {
            let div = document.createElement("div");
            div.classList.add("piece");

            if (i === totalPieces - 1) {
                div.classList.add("empty");
                div.style.background = "none";
            } else {
                let x = (i % gridSize) * -tileSize;
                let y = Math.floor(i / gridSize) * -tileSize;
                div.style.backgroundImage = `url(${imgURL})`;
                div.style.backgroundPosition = `${x}px ${y}px`;
                div.style.backgroundSize = `${gridSize * tileSize}px ${gridSize * tileSize}px`;
                div.dataset.correctIndex = i;
            }

            div.dataset.index = i;
            div.addEventListener("click", manejarMovimiento);
            newPieces.push(div);
        }
        return newPieces;
    }

    function barajarPiezas(piezas) {
        return piezas.sort(() => Math.random() - 0.5);
    }

    function dibujarTablero() {
        puzzle.innerHTML = "";
        pieces.forEach(p => puzzle.appendChild(p));
    }

    function getEmptyIndex() {
        return pieces.findIndex(p => p.classList.contains("empty"));
    }

    function getNeighbors(index) {
        const neighbors = [];
        const n = gridSize;

        if (index % n !== 0) neighbors.push(index - 1);
        if (index % n !== n - 1) neighbors.push(index + 1);
        if (index >= n) neighbors.push(index - n);
        if (index < n * (n - 1)) neighbors.push(index + n);

        return neighbors;
    }

    function manejarMovimiento(event) {
        const piece = event.currentTarget;
        const index = pieces.indexOf(piece);
        const emptyIndex = getEmptyIndex();

        const validMoves = getNeighbors(emptyIndex);

        if (validMoves.includes(index)) {
            [pieces[index], pieces[emptyIndex]] = [pieces[emptyIndex], pieces[index]];

            dibujarTablero();

            moves++;
            actualizarDisplay();

            checkWin();
        }
    }

    function calcularProgreso() {
        let piezasCorrectas = 0;
        const totalPiezasJuego = gridSize * gridSize - 1;

        for (let i = 0; i < pieces.length; i++) {
            const piece = pieces[i];

            if (!piece.classList.contains('empty')) {
                if (parseInt(piece.dataset.correctIndex) === i) {
                    piezasCorrectas++;
                }
            }
        }
        return Math.round((piezasCorrectas / totalPiezasJuego) * 100);
    }

    function checkWin() {
        let won = true;
        for (let i = 0; i < pieces.length; i++) {
            const piece = pieces[i];

            if (!piece.classList.contains('empty')) {
                if (parseInt(piece.dataset.correctIndex) !== i) {
                    won = false;
                    break;
                }
            }
        }

        if (won) {
            setTimeout(() => finalizarJuego(true), 300);
        }
    }

    function finalizarJuego(victoria) {
        const totalPieces = gridSize * gridSize;
        const progreso = calcularProgreso();

        if (victoria) {
            const emptyPiece = pieces[getEmptyIndex()];
            emptyPiece.classList.remove("empty");
            emptyPiece.style.backgroundImage = `url(${imgURL})`;
            let x = ((totalPieces - 1) % gridSize) * -tileSize;
            let y = Math.floor((totalPieces - 1) / gridSize) * -tileSize;
            emptyPiece.style.backgroundPosition = `${x}px ${y}px`;
            emptyPiece.style.backgroundSize = `${gridSize * tileSize}px ${gridSize * tileSize}px`;
            emptyPiece.removeEventListener("click", manejarMovimiento);

            tituloFinal.textContent = "¡Rompecabezas Resuelto! 🎉";
            tituloFinal.style.color = '#00796B';
        } else {
            tituloFinal.textContent = "¡Te has Rendido! 😥";
            tituloFinal.style.color = '#e76f51';
        }

        progresoFinalDisplay.textContent = `${progreso}%`;
        movimientosFinalDisplay.textContent = moves;
        const minimoEstimado = gridSize === 3 ? 15 : 50;
        minimoMovimientosDisplay.textContent = minimoEstimado;

        mensajeFinalOverlay.classList.remove('oculto');
        puzzle.classList.add('oculto');
        infoContenedor.classList.add('oculto');
    }

    function actualizarDisplay() {
        movimientosDisplay.textContent = moves;
    }

    botonesDificultad.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const dificultad = e.target.dataset.dificultad;
            gridSize = dificultad === 'facil' ? 3 : 4;
            iniciarJuego();
        });
    });

    btnRendirse.addEventListener('click', () => {
        if (confirm("¿Estás seguro que quieres rendirte? Perderás tu progreso actual.")) {
            finalizarJuego(false);
        }
    });

    reiniciarJuegoBtn.addEventListener('click', () => {
        mostrarMenuDificultad();
    });

    function mostrarMenuDificultad() {
        seleccionDificultad.classList.remove('oculto');
        infoContenedor.classList.add('oculto');
        puzzle.classList.add('oculto');
        mensajeFinalOverlay.classList.add('oculto');
    }

    mostrarMenuDificultad();
});