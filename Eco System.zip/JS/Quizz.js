const allQuestions = {
    "Facil": [
        {
            question: "¿Qué color se usa generalmente para el contenedor de vidrio?",
            answers: ["Verde", "Amarillo", "Azul"],
            correct: "Verde"
        },
        {
            question: "¿Cuál de estos materiales es reciclable?",
            answers: ["Botellas de plástico", "Cáscaras de huevo", "Papel sucio con comida"],
            correct: "Botellas de plástico"
        },
        {
            question: "¿Cuál es la mejor manera de ahorrar agua en casa?",
            answers: ["Cerrar la llave mientras te cepillas los dientes", "Regar el jardín al mediodía", "Bañarse durante 30 minutos"],
            correct: "Cerrar la llave mientras te cepillas los dientes"
        },
        {
            question: "¿Qué acción ayuda más al planeta?",
            answers: ["Separar la basura", "Usar desechables", "Comprar cosas innecesarias"],
            correct: "Separar la basura"
        },
        {
            question: "¿Qué material se debe tirar en el contenedor azul?",
            answers: ["Papel y cartón", "Plástico", "Vidrio"],
            correct: "Papel y cartón"
        },
        {
            question: "¿Cuál es un beneficio del reciclaje?",
            answers: ["Ahorro de energía", "Aumento de residuos", "Mayor contaminación"],
            correct: "Ahorro de energía"
        },
        {
            question: "¿Las pilas usadas se tiran a la basura normal?",
            answers: ["No, deben ir a un punto de recolección especial", "Sí, no son dañinas", "Solo si están descargadas"],
            correct: "No, deben ir a un punto de recolección especial"
        },
        {
            question: "¿Cuál de estas es una 'R' de la ecología?",
            answers: ["Reducir", "Reparar", "Rechazar"],
            correct: "Reducir"
        },
        {
            question: "¿Se debe lavar el envase de yogur antes de tirarlo al contenedor amarillo?",
            answers: ["No es necesario, solo vaciarlo", "Sí, completamente", "Depende del color"],
            correct: "No es necesario, solo vaciarlo"
        },
        {
            question: "¿El aceite de cocina usado se puede tirar por el fregadero?",
            answers: ["No", "Sí", "Solo si está frío"],
            correct: "No"
        },
        {
            question: "¿Qué significa 'compostar'?",
            answers: ["Hacer abono con residuos orgánicos", "Compactar latas", "Quemar hojas secas"],
            correct: "Hacer abono con residuos orgánicos"
        },
        {
            question: "¿El cartón de leche (tetra brik) se recicla con el papel?",
            answers: ["No, va con los envases (amarillo)", "Sí", "Solo la tapa"],
            correct: "No, va con los envases (amarillo)"
        },
        {
            question: "¿Qué se debe hacer con la ropa vieja?",
            answers: ["Donarla o reutilizarla", "Tirarla a la basura", "Enterrarla"],
            correct: "Donarla o reutilizarla"
        },
        {
            question: "¿Qué animal es el símbolo de la ecología en muchas culturas?",
            answers: ["El Oso Panda", "El Tigre", "El León"],
            correct: "El Oso Panda"
        },
        {
            question: "¿Es mejor usar una bolsa de tela o una de plástico en el supermercado?",
            answers: ["Bolsa de tela", "Bolsa de plástico", "Da igual"],
            correct: "Bolsa de tela"
        },
        {
            question: "¿Se puede reciclar el papel de aluminio?",
            answers: ["Sí", "No", "Solo si está muy limpio"],
            correct: "Sí"
        },
        {
            question: "¿Es un gesto ecológico apagar las luces al salir de una habitación?",
            answers: ["Sí", "No", "Solo si es por mucho tiempo"],
            correct: "Sí"
        },
        {
            question: "¿Qué tipo de residuo es una cáscara de plátano?",
            answers: ["Orgánico", "Plástico", "Vidrio"],
            correct: "Orgánico"
        },
        {
            question: "¿Qué significa el símbolo de las tres flechas entrelazadas?",
            answers: ["Reciclaje", "Peligro", "Prohibido"],
            correct: "Reciclaje"
        },
        {
            question: "¿El periódico viejo debe ir al contenedor azul?",
            answers: ["Sí", "No", "Al contenedor gris"],
            correct: "Sí"
        }
    ],
    "Medio": [
        {
            question: "¿Qué gas es el principal responsable del calentamiento global?",
            answers: ["Dióxido de carbono (CO₂)", "Oxígeno", "Hidrógeno"],
            correct: "Dióxido de carbono (CO₂)"
        },
        {
            question: "¿Cuál es una energía renovable?",
            answers: ["Energía solar", "Petróleo", "Carbón"],
            correct: "Energía solar"
        },
        {
            question: "¿Qué se conoce como 'Huella de Carbono'?",
            answers: ["El total de emisiones de gases de efecto invernadero", "La marca que deja un zapato", "El rastro de carbón en el suelo"],
            correct: "El total de emisiones de gases de efecto invernadero"
        },
        {
            question: "¿Cuánto tiempo tarda una botella de vidrio en degradarse en la naturaleza?",
            answers: ["Miles de años", "50 años", "100 años"],
            correct: "Miles de años"
        },
        {
            question: "¿Qué es la 'Lluvia Ácida'?",
            answers: ["Precipitaciones con sustancias químicas contaminantes", "Lluvia de color azul", "Lluvia que cae muy rápido"],
            correct: "Precipitaciones con sustancias químicas contaminantes"
        },
        {
            question: "¿Qué término describe la variedad de vida en la Tierra?",
            answers: ["Biodiversidad", "Ecología", "Biomasa"],
            correct: "Biodiversidad"
        },
        {
            question: "¿El corcho es reciclable en el contenedor amarillo?",
            answers: ["No, es orgánico o punto limpio", "Sí, es envase", "Solo si es corcho sintético"],
            correct: "No, es orgánico o punto limpio"
        },
        {
            question: "¿Qué es el efecto invernadero?",
            answers: ["Retención del calor en la atmósfera terrestre", "Un invernadero muy caliente", "Una forma de plantar tomates"],
            correct: "Retención del calor en la atmósfera terrestre"
        },
        {
            question: "¿Qué material no se puede reciclar si está sucio?",
            answers: ["Papel y cartón", "Vidrio", "Latas"],
            correct: "Papel y cartón"
        },
        {
            question: "¿Qué tipo de contaminante es el ruido excesivo?",
            answers: ["Contaminación acústica", "Contaminación lumínica", "Contaminación térmica"],
            correct: "Contaminación acústica"
        },
        {
            question: "¿Cuál es la principal fuente de energía en el planeta que impulsa el ciclo del agua?",
            answers: ["El Sol", "El viento", "La geotermia"],
            correct: "El Sol"
        },
        {
            question: "¿El plástico PET se utiliza principalmente para qué productos?",
            answers: ["Botellas de bebidas", "Electrodomésticos", "Ropa de algodón"],
            correct: "Botellas de bebidas"
        },
        {
            question: "¿Qué se entiende por 'consumo responsable'?",
            answers: ["Comprar solo lo necesario y de forma ética", "Comprar mucho en rebajas", "Comprar marcas caras"],
            correct: "Comprar solo lo necesario y de forma ética"
        },
        {
            question: "¿Qué animal marino está más amenazado por el plástico?",
            answers: ["Tortugas marinas", "Delfines", "Tiburones"],
            correct: "Tortugas marinas"
        },
        {
            question: "¿Qué es un microplástico?",
            answers: ["Un trozo de plástico muy pequeño, menor a 5mm", "Un microondas de plástico", "Un envase de yogur"],
            correct: "Un trozo de plástico muy pequeño, menor a 5mm"
        },
        {
            question: "¿Qué tipo de residuos se depositan en el contenedor gris/resto?",
            answers: ["Los no reciclables", "Solo vidrio", "Solo papel"],
            correct: "Los no reciclables"
        },
        {
            question: "¿Es la energía hidroeléctrica una fuente de energía renovable?",
            answers: ["Sí", "No", "Solo en invierno"],
            correct: "Sí"
        },
        {
            question: "¿Qué se debe hacer con los medicamentos caducados?",
            answers: ["Llevarlos a un punto SIGRE (farmacias)", "Tirarlos a la basura", "Tirarlos por el inodoro"],
            correct: "Llevarlos a un punto SIGRE (farmacias)"
        },
        {
            question: "¿Qué significa la etiqueta 'Clase A' o 'A+' en un electrodoméstico?",
            answers: ["Alta eficiencia energética", "Baja calidad", "Es muy antiguo"],
            correct: "Alta eficiencia energética"
        },
        {
            question: "¿Cuál es el principal componente de las botellas de agua desechables?",
            answers: ["Plástico (PET)", "Aluminio", "Vidrio"],
            correct: "Plástico (PET)"
        }
    ],
    "Dificil": [
        {
            question: "¿Qué compuesto químico es el responsable de dañar la capa de ozono?",
            answers: ["Clorofluorocarbonos (CFC)", "Dióxido de carbono (CO₂)", "Metano"],
            correct: "Clorofluorocarbonos (CFC)"
        },
        {
            question: "¿Qué porcentaje del agua del planeta es agua dulce disponible para consumo humano?",
            answers: ["Menos del 1%", "Aproximadamente el 10%", "Casi el 50%"],
            correct: "Menos del 1%"
        },
        {
            question: "¿Qué es la 'eutrofización' en cuerpos de agua?",
            answers: ["Aumento excesivo de nutrientes que causa falta de oxígeno", "Un método de limpieza", "Una forma de pesca"],
            correct: "Aumento excesivo de nutrientes que causa falta de oxígeno"
        },
        {
            question: "¿Cuál es el principal desafío de reciclar plásticos mixtos?",
            answers: ["La dificultad de separación y procesamiento por tipo de polímero", "El olor", "Son demasiado pesados"],
            correct: "La dificultad de separación y procesamiento por tipo de polímero"
        },
        {
            question: "¿Cuál es el tratado internacional clave para combatir el cambio climático?",
            answers: ["Acuerdo de París", "Protocolo de Kioto", "Protocolo de Montreal"],
            correct: "Acuerdo de París"
        },
        {
            question: "¿Qué tipo de contaminación se asocia con el 'smog' en las ciudades?",
            answers: ["Contaminación del aire", "Contaminación del suelo", "Contaminación visual"],
            correct: "Contaminación del aire"
        },
        {
            question: "¿Qué significa el término 'biomagnificación'?",
            answers: ["Aumento de la concentración de contaminantes a medida que sube la cadena trófica", "Crecimiento de plantas", "Uso de fertilizantes"],
            correct: "Aumento de la concentración de contaminantes a medida que sube la cadena trófica"
        },
        {
            question: "¿Cuál es la función principal de un humedal?",
            answers: ["Filtrar contaminantes del agua y proteger de inundaciones", "Generar electricidad", "Servir como basurero"],
            correct: "Filtrar contaminantes del agua y proteger de inundaciones"
        },
        {
            question: "¿Cuál de estos gases tiene un potencial de calentamiento global (PCG) mucho mayor que el CO₂?",
            answers: ["Metano (CH₄)", "Oxígeno (O₂)", "Nitrógeno (N₂)"],
            correct: "Metano (CH₄)"
        },
        {
            question: "¿Qué es un 'ecopunto' o 'punto limpio'?",
            answers: ["Lugar para depositar residuos especiales (pilas, aceites, escombros)", "Un área verde de la ciudad", "Un contenedor de basura normal"],
            correct: "Lugar para depositar residuos especiales (pilas, aceites, escombros)"
        },
        {
            question: "¿Qué es la deforestación?",
            answers: ["La destrucción o tala de bosques y selvas", "Plantar árboles", "El estudio de los árboles"],
            correct: "La destrucción o tala de bosques y selvas"
        },
        {
            question: "¿Qué tipo de residuos son los aparatos electrónicos viejos (RAEE)?",
            answers: ["Residuos peligrosos", "Residuos orgánicos", "Residuos inertes"],
            correct: "Residuos peligrosos"
        },
        {
            question: "¿Qué es el Protocolo de Montreal?",
            answers: ["Tratado para proteger la capa de ozono, eliminando CFCs", "Acuerdo de pesca", "Tratado contra la contaminación del agua"],
            correct: "Tratado para proteger la capa de ozono, eliminando CFCs"
        },
        {
            question: "¿Qué porcentaje de la energía consumida en el mundo proviene de combustibles fósiles (aproximadamente)?",
            answers: ["Más del 80%", "Alrededor del 25%", "Menos del 10%"],
            correct: "Más del 80%"
        },
        {
            question: "¿El uso de bicicletas en lugar de coches ayuda a reducir qué tipo de contaminación principalmente?",
            answers: ["Contaminación del aire", "Contaminación lumínica", "Contaminación visual"],
            correct: "Contaminación del aire"
        },
        {
            question: "¿Qué es la 'energía geotérmica'?",
            answers: ["Energía que proviene del calor interno de la Tierra", "Energía del viento", "Energía del sol"],
            correct: "Energía que proviene del calor interno de la Tierra"
        },
        {
            question: "¿Qué tipo de residuo es el que NO se descompone?",
            answers: ["Residuo inerte", "Residuo orgánico", "Residuo peligroso"],
            correct: "Residuo inerte"
        },
        {
            question: "¿Cuál es el principal efecto de la acidificación de los océanos?",
            answers: ["Dificulta la formación de caparazones y esqueletos de organismos marinos", "Aumenta la temperatura del agua", "Hace que el agua sea más salada"],
            correct: "Dificulta la formación de caparazones y esqueletos de organismos marinos"
        },
        {
            question: "¿Qué es la 'obsolescencia programada'?",
            answers: ["Diseñar productos para que duren poco y deban ser reemplazados", "Una nueva ley de reciclaje", "Un tipo de contaminación"],
            correct: "Diseñar productos para que duren poco y deban ser reemplazados"
        },
        {
            question: "¿Qué significan las siglas ODS?",
            answers: ["Objetivos de Desarrollo Sostenible", "Organización de Desechos Sólidos", "Observatorio de Desastres Naturales"],
            correct: "Objetivos de Desarrollo Sostenible"
        }
    ]
};

const MAX_QUESTIONS = 10;
let selectedQuestions = [];
let current = 0;
let score = 0;
let userAnswers = [];

const quizContainer = document.querySelector('.quiz-container');
const startScreen = document.getElementById('start-screen');
const quizScreen = document.getElementById('quiz-screen');
const scoreDisplay = document.getElementById("score");
const restartButton = document.getElementById("restart");

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function startGame(difficulty) {
    let pool = [...allQuestions[difficulty]];

    shuffle(pool);
    selectedQuestions = pool.slice(0, MAX_QUESTIONS);

    current = 0;
    score = 0;
    userAnswers = [];

    startScreen.classList.add('oculto');
    quizScreen.classList.remove('oculto');
    restartButton.style.display = 'none';
    scoreDisplay.innerHTML = '';

    loadQuestion();
}

function loadQuestion() {
    const currentQuestionData = selectedQuestions[current];
    document.getElementById("question").textContent = `${current + 1}/${MAX_QUESTIONS}. ${currentQuestionData.question}`;

    const answersDiv = document.getElementById("answers");
    answersDiv.innerHTML = "";

    const shuffledAnswers = shuffle([...currentQuestionData.answers]);

    shuffledAnswers.forEach((answer) => {
        const btn = document.createElement("button");
        btn.textContent = answer;
        btn.onclick = () => checkAnswer(answer);
        answersDiv.appendChild(btn);
    });
}

function checkAnswer(selectedAnswer) {
    const currentQuestionData = selectedQuestions[current];
    const isCorrect = selectedAnswer === currentQuestionData.correct;

    userAnswers.push({
        question: currentQuestionData.question,
        selected: selectedAnswer,
        correct: currentQuestionData.correct,
        isCorrect: isCorrect
    });

    if (isCorrect) {
        score++;
    }

    current++;

    if (current < MAX_QUESTIONS) {
        loadQuestion();
    } else {
        finishQuiz();
    }
}

function finishQuiz() {
    quizScreen.classList.add('oculto');

    const totalQuestions = MAX_QUESTIONS;
    const correctAnswers = score;
    const incorrectAnswers = totalQuestions - score;

    let finalMessage = `
        <h2>¡Cuestionario Terminado!</h2>
        <p>Tu puntuación final es: <strong>${correctAnswers} / ${totalQuestions}</strong></p>
        <p>Correctas: <strong class="correct">${correctAnswers}</strong> | Incorrectas: <strong class="selected">${incorrectAnswers}</strong></p>
    `;

    const incorrectFeedback = userAnswers.filter(answer => !answer.isCorrect);

    if (incorrectFeedback.length > 0) {
        finalMessage += '<h3>Respuestas Incorrectas:</h3><ul>';
        incorrectFeedback.forEach(feedback => {
            finalMessage += `
                <li>
                    <strong>Pregunta:</strong> ${feedback.question}<br>
                    <strong>Tu Respuesta:</strong> <span class="selected">${feedback.selected}</span><br>
                    <strong>Respuesta Correcta:</strong> <span class="correct">${feedback.correct}</span>
                </li>
            `;
        });
        finalMessage += '</ul>';
    } else {
        finalMessage += '<p class="correct">¡Felicidades, no tuviste errores!</p>';
    }

    scoreDisplay.innerHTML = finalMessage;
    restartButton.style.display = "block";
    restartButton.onclick = restartQuiz;
}

function restartQuiz() {
    quizScreen.classList.add('oculto');
    startScreen.classList.remove('oculto');
    restartButton.style.display = 'none';
    scoreDisplay.innerHTML = '';
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('btn-facil').onclick = () => startGame('Facil');
    document.getElementById('btn-medio').onclick = () => startGame('Medio');
    document.getElementById('btn-dificil').onclick = () => startGame('Dificil');

    startScreen.classList.remove('oculto');
    quizScreen.classList.add('oculto');
    restartButton.style.display = 'none';
});