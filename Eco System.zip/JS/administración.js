document.addEventListener('DOMContentLoaded', () => {
    const role = localStorage.getItem('role');
    if (role !== 'admin') {
        alert('Acceso denegado. Solo administradores.');
        window.location.href = 'index.html';
        return;
    }

    // --- FUNCIONES DE GESTIÓN DE LOCALSTORAGE ---
    const getDocentes = () => JSON.parse(localStorage.getItem('docentes')) || {};
    const saveDocentes = (docentes) => localStorage.setItem('docentes', JSON.stringify(docentes));
    const getGrupos = () => JSON.parse(localStorage.getItem('grupos')) || {};
    const saveGrupos = (grupos) => localStorage.setItem('grupos', JSON.stringify(grupos));

    // 🚨 FUNCIONES PARA FOTOS PENDIENTES
    const getFotos = () => JSON.parse(localStorage.getItem('fotosPendientes')) || {};
    const saveFotos = (fotos) => localStorage.setItem('fotosPendientes', JSON.stringify(fotos));
    
    // 🚨 FUNCIONES PARA GALERÍA APROBADA
    const getGaleria = () => JSON.parse(localStorage.getItem('galeriaFotos')) || {};
    const saveGaleria = (fotos) => localStorage.setItem('galeriaFotos', JSON.stringify(fotos));


    // --- DECLARACIÓN DE ELEMENTOS DOCENTES ---
    const altaDocenteForm = document.getElementById('altaDocenteForm');
    const docenteNombreInput = document.getElementById('docenteNombre');
    const docenteControlInput = document.getElementById('docenteControl');
    const docenteEmailInput = document.getElementById('docenteEmail');
    const listaDocentesUl = document.getElementById('listaDocentes');
    const limpiarDocentesBtn = document.getElementById('limpiarDocentesBtn');

    // --- DECLARACIÓN DE ELEMENTOS GRUPOS ---
    const altaGrupoForm = document.getElementById('altaGrupoForm');
    const grupoNombreInput = document.getElementById('grupoNombre');
    const grupoEspecialidadInput = document.getElementById('grupoEspecialidad');
    const grupoTurnoInput = document.getElementById('grupoTurno');
    const listaGruposUl = document.getElementById('listaGrupos');
    const limpiarGruposBtn = document.getElementById('limpiarGruposBtn');

    // --- 🚨 NUEVO ELEMENTO PARA FOTOS
    const listaFotosUl = document.getElementById('listaFotosPendientes');


    // --- FUNCIÓN MOSTRAR DOCENTES ---
    function mostrarDocentes() {
        const docentes = getDocentes();
        listaDocentesUl.innerHTML = '';

        if (Object.keys(docentes).length === 0) {
            listaDocentesUl.innerHTML = '<li style="color:#777; text-align: center;">No hay docentes registrados aún.</li>';
            return;
        }

        Object.keys(docentes).forEach(control => {
            const docente = docentes[control];
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${docente.nombre} (${control})</span>
                <button type="button" class="boton-baja" data-control="${control}">Dar de Baja</button>
            `;
            listaDocentesUl.appendChild(li);
        });
    }

    // --- FUNCIÓN MOSTRAR GRUPOS ---
    function mostrarGrupos() {
        const grupos = getGrupos();
        listaGruposUl.innerHTML = '';

        if (Object.keys(grupos).length === 0) {
            listaGruposUl.innerHTML = '<li style="color:#777; text-align: center;">No hay grupos registrados aún.</li>';
            return;
        }

        Object.keys(grupos).forEach(id => {
            const grupo = grupos[id];
            const li = document.createElement('li');
            li.innerHTML = `
                <span>${grupo.nombre} (${grupo.especialidad}, ${grupo.turno})</span>
                <button type="button" class="boton-baja" data-id="${id}">Dar de Baja</button>
            `;
            listaGruposUl.appendChild(li);
        });
    }

    // --- 🚨 NUEVA FUNCIÓN MOSTRAR FOTOS ---
    function mostrarFotos() {
        const fotos = getFotos();
        if (!listaFotosUl) return; // Salir si el elemento no existe

        listaFotosUl.innerHTML = '';
        // Convertimos el objeto a array y filtramos, aunque en este caso todas deberían ser 'pendiente'
        const fotosPendientes = Object.values(fotos).filter(foto => foto.status === 'pendiente');

        if (fotosPendientes.length === 0) {
            listaFotosUl.innerHTML = '<li style="color:#777; text-align: center;">No hay fotos pendientes de revisión.</li>';
            return;
        }

        fotosPendientes.forEach(foto => {
            const li = document.createElement('li');
            li.innerHTML = `
                <div class="foto-detalle-admin">
                    <img src="${foto.imageDataUrl}" alt="Previsualización de ${foto.descripcion}" class="foto-preview"> 
                    <div>
                        <span>**${foto.descripcion}** (${foto.fileName})</span>
                        <span style="display: block; font-size: 0.8em; color: #999;">Enviada por: ${foto.usuario || 'Desconocido'} | Fecha: ${new Date(foto.timestamp).toLocaleDateString('es-MX')}</span>
                    </div>
                </div>
                <div class="foto-acciones">
                    <button type="button" class="boton-aprobar" data-id="${foto.id}">Aprobar</button>
                    <button type="button" class="boton-rechazar" data-id="${foto.id}">Rechazar</button>
                </div>
            `;
            listaFotosUl.appendChild(li);
        });
    }


    // --- LISTENERS DOCENTES ---
    if (altaDocenteForm) {
        altaDocenteForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const nombre = docenteNombreInput.value.trim();
            const control = docenteControlInput.value.trim();
            const email = docenteEmailInput.value.trim();

            if (!/^(\d{14})$/.test(control)) {
                alert('❌ Error: El No. Control debe ser exactamente de 14 dígitos numéricos.');
                return;
            }

            let docentes = getDocentes();

            if (docentes[control]) {
                alert(`❌ Error: El docente con No. Control ${control} ya está registrado.`);
                return;
            }

            docentes[control] = {
                nombre: nombre,
                email: email,
                control: control,
                role: 'docente'
            };

            saveDocentes(docentes);
            alert(`✅ Docente ${nombre} registrado exitosamente.`);
            altaDocenteForm.reset();
            mostrarDocentes();
        });
    }

    if (listaDocentesUl) {
        listaDocentesUl.addEventListener('click', (e) => {
            if (e.target.classList.contains('boton-baja')) {
                const control = e.target.getAttribute('data-control');
                if (confirm(`¿Está seguro de dar de baja al docente con No. Control ${control}?`)) {
                    let docentes = getDocentes();
                    delete docentes[control];
                    saveDocentes(docentes);
                    alert(`✅ Docente con No. Control ${control} dado de baja.`);
                    mostrarDocentes();
                }
            }
        });
    }

    if (limpiarDocentesBtn) {
        limpiarDocentesBtn.addEventListener('click', () => {
            if (confirm('🚨 ADVERTENCIA: Esta acción BORRARÁ todos los datos de Docentes. ¿Continuar?')) {
                localStorage.removeItem('docentes');
                alert('Datos de docentes eliminados.');
                mostrarDocentes();
            }
        });
    }

    // --- LISTENERS GRUPOS ---
    if (altaGrupoForm) {
        altaGrupoForm.addEventListener('submit', (e) => {
            e.preventDefault();

            const nombre = grupoNombreInput.value.trim();
            const especialidad = grupoEspecialidadInput.value;
            const turno = grupoTurnoInput.value;
            const id = `${nombre}-${especialidad}-${turno}`;

            if (!nombre || !especialidad || !turno) {
                alert('Por favor, selecciona o ingresa todos los campos para el grupo.');
                return;
            }

            let grupos = getGrupos();

            if (grupos[id]) {
                alert(`❌ Error: El grupo ${nombre} ya está registrado con esa especialidad y turno.`);
                return;
            }

            grupos[id] = {
                nombre: nombre,
                especialidad: especialidad,
                turno: turno,
                id: id
            };

            saveGrupos(grupos);
            alert(`✅ Grupo ${nombre} registrado exitosamente.`);
            altaGrupoForm.reset();
            mostrarGrupos();
        });
    }

    if (listaGruposUl) {
        listaGruposUl.addEventListener('click', (e) => {
            if (e.target.classList.contains('boton-baja')) {
                const id = e.target.getAttribute('data-id');
                const [nombreGrupo] = id.split('-');
                if (confirm(`¿Está seguro de dar de baja al grupo ${nombreGrupo}?`)) {
                    let grupos = getGrupos();
                    delete grupos[id];
                    saveGrupos(grupos);
                    alert(`✅ Grupo ${nombreGrupo} dado de baja.`);
                    mostrarGrupos();
                }
            }
        });
    }

    if (limpiarGruposBtn) {
        limpiarGruposBtn.addEventListener('click', () => {
            if (confirm('🚨 ADVERTENCIA: Esta acción BORRARÁ todos los datos de Grupos. ¿Continuar?')) {
                localStorage.removeItem('grupos');
                alert('Datos de grupos eliminados.');
                mostrarGrupos();
            }
        });
    }

    // --- 🚨 NUEVO LISTENER GESTIÓN DE FOTOS ---
    if (listaFotosUl) {
        listaFotosUl.addEventListener('click', (e) => {
            const id = e.target.getAttribute('data-id');
            if (!id) return;

            let fotos = getFotos();
            const foto = fotos[id];

            if (!foto) return;

            if (e.target.classList.contains('boton-aprobar')) {
                if (confirm(`¿Aprobar la foto: "${foto.descripcion}"?`)) {

                    let galeria = getGaleria();
                    let submitterControl = foto.usuario || '98765432101234'; // Usar el usuario que subió la foto

                    // 1. Crear el objeto de la galería con metadatos
                    galeria[id] = {
                        id: id,
                        imageDataUrl: foto.imageDataUrl,
                        descripcion: foto.descripcion,
                        controlUsuario: submitterControl,
                        fechaPublicacion: new Date().toLocaleDateString('es-MX'), // Fecha de hoy
                        // Incluimos el timestamp original de la foto pendiente para ordenamiento
                        timestamp: foto.timestamp 
                    };
                    saveGaleria(galeria);

                    // 2. Eliminar de la lista de pendientes
                    delete fotos[id];
                    saveFotos(fotos); // Guarda la lista de pendientes actualizada

                    alert('✅ Foto aprobada y publicada en la Galería de la Comunidad.');
                    mostrarFotos(); // Re-renderiza la lista de pendientes
                }
            } else if (e.target.classList.contains('boton-rechazar')) {
                if (confirm(`¿Rechazar la foto: "${foto.descripcion}"?`)) {
                    // Para rechazar, eliminamos la foto del almacenamiento
                    delete fotos[id];
                    saveFotos(fotos);
                    alert('❌ Foto rechazada y eliminada.');
                    mostrarFotos();
                }
            }
        });
    }
    
    // --- LLAMADAS INICIALES ---
    mostrarDocentes();
    mostrarGrupos();
    mostrarFotos(); 
});