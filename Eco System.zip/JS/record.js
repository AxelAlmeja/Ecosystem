const especialidades = [
  "Programación",
  "Puericultura",
  "Servicios de Hospedaje",
  "Administración de Empresas",
  "Contabilidad",
  "Electrónica"
];

const asignaciones = [];

const NUM_ESPECIALIDADES = especialidades.length;
for (let dia = 1; dia <= 30; dia += 3) {
  const grupoIndex = Math.floor((dia - 1) / 3);
  const especialidad = especialidades[grupoIndex % NUM_ESPECIALIDADES];
  asignaciones.push({
    grupo: `Día ${dia}`,
    especialidad,
    fecha: `${dia} de Noviembre`
  });
}

const contenedorAsignaciones = document.getElementById("contenedorAsignaciones");

asignaciones.forEach(asignacion => {
  const div = document.createElement("div");
  div.classList.add("asignacion");
  div.innerHTML = `
    <p>Asignación de Riego: <strong>${asignacion.fecha}</strong></p>
    <p>Especialidad asignada: <strong>${asignacion.especialidad}</strong></p>
  `;
  contenedorAsignaciones.appendChild(div);
});


const TASA_TAPAS_POR_KILO = 1000;

function obtenerRecolecciones() {
  const recoleccionesJSON = localStorage.getItem('recoleccionesTapas') || '[]';
  return JSON.parse(recoleccionesJSON);
}

function guardarRecolecciones(recolecciones) {
  localStorage.setItem('recoleccionesTapas', JSON.stringify(recolecciones));
}

function actualizarEstadisticas() {
  const recolecciones = obtenerRecolecciones();

  const totalTapas = recolecciones.reduce((sum, rec) => sum + rec.cantidad, 0);
  document.getElementById('totalTapas').textContent = totalTapas.toLocaleString('es-MX');

  const totalKilos = (totalTapas / TASA_TAPAS_POR_KILO).toFixed(2);
  document.getElementById('totalKilos').textContent = `${totalKilos} kg`;

  const conteoEspecialidades = recolecciones.reduce((acc, rec) => {
    acc[rec.especialidad] = (acc[rec.especialidad] || 0) + rec.cantidad;
    return acc;
  }, {});

  let especialidadLider = 'N/A';
  let maxTapas = -1;

  for (const [especialidad, tapas] of Object.entries(conteoEspecialidades)) {
    if (tapas > maxTapas) {
      maxTapas = tapas;
      especialidadLider = especialidad;
    }
  }
  document.getElementById('especialidadLider').textContent = especialidadLider;

  const ultimaRecoleccion = recolecciones.length > 0
    ? new Date(recolecciones[recolecciones.length - 1].fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })
    : 'N/A';
  document.getElementById('ultimaRecoleccion').textContent = ultimaRecoleccion;
}

document.getElementById('formTapas').addEventListener('submit', function (e) {
  e.preventDefault();

  const especialidad = document.getElementById('especialidad').value;
  const grupo = document.getElementById('grupo').value;
  const turno = document.getElementById('turno').value;
  const cantidad = parseInt(document.getElementById('cantidad').value, 10);

  if (cantidad <= 0) {
    alert("La cantidad debe ser un número positivo.");
    return;
  }

  const nuevaRecoleccion = {
    especialidad,
    grupo,
    turno,
    cantidad,
    fecha: new Date().toISOString()
  };

  const recolecciones = obtenerRecolecciones();
  recolecciones.push(nuevaRecoleccion);
  guardarRecolecciones(recolecciones);

  actualizarEstadisticas();

  const resultadoDiv = document.createElement("div");
  resultadoDiv.classList.add("asignacion");
  resultadoDiv.innerHTML = `
    <h2 style="color: #2A5B5F; margin-bottom: 10px; text-align: center;">¡Registro de tapas exitoso!</h2>
    <p><strong>Especialidad:</strong> ${especialidad}</p>
    <p><strong>Grupo:</strong> ${grupo}</p>
    <p><strong>Turno:</strong> ${turno}</p>
    <p style="font-size: 1.5em; font-weight: bold; color: #579E9E; margin-top: 15px;">+${cantidad.toLocaleString('es-MX')} tapas</p>
  `;

  const registroContenedor = document.getElementById("resultadoRegistro");
  registroContenedor.innerHTML = '';
  registroContenedor.appendChild(resultadoDiv);

  resultadoDiv.style.backgroundColor = '#e6f7e6';
  resultadoDiv.style.borderLeftColor = '#579E9E';

  document.getElementById('formTapas').reset();
});

const botonReiniciar = document.getElementById('reiniciarContadorBtn');
if (botonReiniciar) {
  botonReiniciar.addEventListener('click', () => {
    if (confirm("¿Estás seguro de que deseas reiniciar todos los contadores de tapas? Esta acción no se puede deshacer.")) {
      localStorage.removeItem('recoleccionesTapas');
      actualizarEstadisticas();
      const registroContenedor = document.getElementById("resultadoRegistro");
      registroContenedor.innerHTML = '<div class="asignacion" style="background-color:#fff0e6; border-left: 5px solid #c0392b; text-align: center;"><h2 style="color:#c0392b;">Contadores Reiniciados</h2><p>Todas las estadísticas han vuelto a cero.</p></div>';
      document.getElementById('formTapas').reset();
    }
  });
}


document.addEventListener('DOMContentLoaded', () => {
  actualizarEstadisticas();
});