/**
 * LÓGICA DEL PANEL DE ADMINISTRACIÓN
 * Gestión de Grupos, Docentes y Moderación de Imágenes.
 */

document.addEventListener('DOMContentLoaded', () => {
    // VERIFICACIÓN DE SEGURIDAD
    const role = localStorage.getItem('role');
    if (role !== 'admin') {
        Utils.Toast.show('Acceso Denegado. Solo administradores.', 'error');
        setTimeout(() => window.location.href = 'index.html', 2000);
        return;
    }

    Utils.UI.updateNavbar();
    loadGroups();
    loadTeachers();
    loadModerationQueue();

    // ============================
    // GESTIÓN DE GRUPOS
    // ============================
    document.getElementById('form-add-group').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('group-name').value.trim();
        const shift = document.getElementById('group-shift').value;

        if (!name) return;

        const groups = getGroups();
        groups.push({ id: Date.now(), name, shift, active: true });
        saveGroups(groups);

        Utils.Toast.show('Grupo agregado exitosamente.', 'success');
        document.getElementById('form-add-group').reset();
        loadGroups();
    });

    // ============================
    // GESTIÓN DE DOCENTES
    // ============================
    document.getElementById('form-add-teacher').addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('teacher-name').value.trim();
        const area = document.getElementById('teacher-area').value.trim();

        if (!name || !area) return;

        const teachers = getTeachers();
        teachers.push({ id: Date.now(), name, area, active: true });
        saveTeachers(teachers);

        Utils.Toast.show('Docente agregado exitosamente.', 'success');
        document.getElementById('form-add-teacher').reset();
        loadTeachers();
    });
});

// ============================
// AYUDANTES DE DATOS (DATA HELPERS)
// ============================
function getGroups() { return JSON.parse(localStorage.getItem('admin_groups')) || []; }
function saveGroups(data) { localStorage.setItem('admin_groups', JSON.stringify(data)); }

function getTeachers() { return JSON.parse(localStorage.getItem('admin_teachers')) || []; }
function saveTeachers(data) { localStorage.setItem('admin_teachers', JSON.stringify(data)); }

function getPendingRecords() { return JSON.parse(localStorage.getItem('pending_records')) || []; }
function savePendingRecords(data) { localStorage.setItem('pending_records', JSON.stringify(data)); }

// ============================
// FUNCIONES DE RENDERIZADO
// ============================
function loadGroups() {
    const list = document.getElementById('list-groups');
    list.innerHTML = '';
    const groups = getGroups();

    groups.forEach(group => {
        const tr = document.createElement('tr');
        tr.style.opacity = group.active ? '1' : '0.6';
        tr.innerHTML = `
            <td style="padding:10px;">${group.name}</td>
            <td style="padding:10px;">${group.shift}</td>
            <td style="padding:10px;">${group.active ? '✅ Activo' : '❌ Inactivo'}</td>
            <td style="padding:10px; text-align: right;">
                <button class="btn btn-sm" onclick="toggleGroup(${group.id})" style="background-color: ${group.active ? '#f39c12' : '#2ecc71'}; margin-right: 5px;">
                    ${group.active ? 'Desactivar' : 'Activar'}
                </button>
                <button class="btn btn-sm" onclick="deleteGroup(${group.id})" style="background-color: #c0392b;">
                    Eliminar
                </button>
            </td>
        `;
        list.appendChild(tr);
    });
}

function loadTeachers() {
    const list = document.getElementById('list-teachers');
    list.innerHTML = '';
    const teachers = getTeachers();

    teachers.forEach(teacher => {
        const tr = document.createElement('tr');
        tr.style.opacity = teacher.active ? '1' : '0.6';
        tr.innerHTML = `
            <td style="padding:10px;">${teacher.name}</td>
            <td style="padding:10px;">${teacher.area}</td>
            <td style="padding:10px;">${teacher.active ? '✅ Activo' : '❌ Inactivo'}</td>
            <td style="padding:10px; text-align: right;">
                <button class="btn btn-sm" onclick="toggleTeacher(${teacher.id})" style="background-color: ${teacher.active ? '#f39c12' : '#2ecc71'}; margin-right: 5px;">
                    ${teacher.active ? 'Desactivar' : 'Activar'}
                </button>
                <button class="btn btn-sm" onclick="deleteTeacher(${teacher.id})" style="background-color: #c0392b;">
                    Eliminar
                </button>
            </td>
        `;
        list.appendChild(tr);
    });
}

window.deleteGroup = function (id) {
    if (!confirm('¿Estás seguro de ELIMINAR este grupo? Esta acción no se puede deshacer.')) return;

    const groups = getGroups();
    const newGroups = groups.filter(g => g.id !== id);
    saveGroups(newGroups);
    loadGroups();
    Utils.Toast.show('Grupo eliminado.', 'success');
};

window.deleteTeacher = function (id) {
    if (!confirm('¿Estás seguro de ELIMINAR este docente? Esta acción no se puede deshacer.')) return;

    const teachers = getTeachers();
    const newTeachers = teachers.filter(t => t.id !== id);
    saveTeachers(newTeachers);
    loadTeachers();
    Utils.Toast.show('Docente eliminado.', 'success');
};

function loadModerationQueue() {
    const container = document.getElementById('moderation-grid');
    const queue = getPendingRecords();
    const badge = document.getElementById('tab-moderation');

    // Actualizar conteo de la pestaña
    badge.innerText = `Moderación (${queue.length})`;
    container.innerHTML = '';

    if (queue.length === 0) {
        container.innerHTML = '<p style="grid-column: 1/-1; text-align:center;">No hay revisiones pendientes.</p>';
        return;
    }

    queue.forEach(item => {
        const card = document.createElement('div');
        card.className = 'glass-container';
        card.style.background = 'rgba(255,255,255,0.7)';
        card.innerHTML = `
            <h4>${item.especialidad}</h4>
            <div style="font-size: 0.9em; margin-bottom: 10px;">
                <p><strong>Grupo:</strong> ${item.grupo} - ${item.turno}</p>
                <p><strong>Cantidad:</strong> ${item.cantidad}</p>
                <p><strong>Fecha:</strong> ${new Date(item.date).toLocaleDateString()}</p>
            </div>
            
            <div style="margin-bottom: 15px; cursor: pointer;" onclick="openImage('${item.image}')">
                <img src="${item.image}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px;">
                <small style="display:block; text-align:center; color: var(--primary-color);">Click para ampliar</small>
            </div>

            <div style="display: flex; gap: 10px;">
                <button class="btn btn-sm" style="flex:1; background-color: #2ecc71;" onclick="approveRecord(${item.id})">Aceptar</button>
                <button class="btn btn-sm" style="flex:1; background-color: #e74c3c;" onclick="rejectRecord(${item.id})">Rechazar</button>
            </div>
        `;
        container.appendChild(card);
    });
}

// ============================
// ACCIONES
// ============================
window.toggleGroup = function (id) {
    const groups = getGroups();
    const idx = groups.findIndex(g => g.id === id);
    if (idx !== -1) {
        groups[idx].active = !groups[idx].active;
        saveGroups(groups);
        loadGroups();
    }
};

window.toggleTeacher = function (id) {
    const teachers = getTeachers();
    const idx = teachers.findIndex(t => t.id === id);
    if (idx !== -1) {
        teachers[idx].active = !teachers[idx].active;
        saveTeachers(teachers);
        loadTeachers();
    }
};

window.openImage = function (src) {
    document.getElementById('modal-img').src = src;
    document.getElementById('image-modal').style.display = 'flex';
};

window.approveRecord = function (id) {
    const queue = getPendingRecords();
    const index = queue.findIndex(i => i.id === id);
    if (index === -1) return;

    const item = queue[index];

    // Sumar a estadísticas globales
    let totalTapas = parseInt(localStorage.getItem('totalTapas')) || 0;
    totalTapas += parseInt(item.cantidad);
    localStorage.setItem('totalTapas', totalTapas);

    queue.splice(index, 1);
    savePendingRecords(queue);

    Utils.Toast.show('Registro aprobado y sumado al total.', 'success');
    loadModerationQueue();
};

window.rejectRecord = function (id) {
    if (!confirm('¿Estás seguro de rechazar este registro?')) return;

    const queue = getPendingRecords();
    const index = queue.findIndex(i => i.id === id);
    if (index !== -1) {
        queue.splice(index, 1);
        savePendingRecords(queue);
        Utils.Toast.show('Registro rechazado.', 'info');
        loadModerationQueue();
    }
};
