// INICIALIZACIÓN DEL JUEGO DE MEMORAMA
document.addEventListener('DOMContentLoaded', () => {
    const tablero = document.getElementById('tablero');
    const nivelDisplay = document.getElementById('nivel');
    const vidasDisplay = document.getElementById('vidas');
    const puntosDisplay = document.getElementById('puntos');
    const titulo = document.getElementById('titulo');
    const mensajeFinalOverlay = document.getElementById('mensaje-final-overlay');
    const mensajeFinal = document.getElementById('mensaje-final');
    const puntuacionFinalDisplay = document.getElementById('puntuacion-final');
    const reiniciarJuegoBtn = document.getElementById('reiniciar-juego');
    const textoMaxPuntuacion = document.getElementById('texto-max-puntuacion');

    let nivel = 1;
    let vidas = 3;
    let puntos = 0;
    let puntuacionMaxima = parseInt(localStorage.getItem('puntuacionMaxima')) || 0;
    let cartas = [];
    let cartasVolteadas = [];
    let bloqueado = false;
    let colores = ['#264653', '#2a9d8f', '#e9c46a', '#f4a261', '#e76f51'];

    function cambiarColorTitulo() {
        let i = 0;
        setInterval(() => {
            titulo.style.color = colores[i];
            i = (i + 1) % colores.length;
        }, 1000);
    }
    cambiarColorTitulo();

    function iniciarJuego() {
        if (nivel === 1) {
            vidas = 3;
            puntos = 0;
        }

        cartas = crearCartas(nivel);
        barajarCartas(cartas);
        generarTablero(cartas);
        actualizarDisplay();

        mensajeFinalOverlay.classList.add('oculto');
    }

    function crearCartas(nivel) {
        const numCartas = nivel * 4;

        const imagenes = [
            'IMG/botella.png',
            'IMG/papel.png',
            'IMG/lata.png',
            'IMG/organico.png',
            'IMG/Carton.png',
            'IMG/ficha.png'
        ];
        let cartas = [];

        const imagenesSeleccionadas = [];
        for (let i = 0; i < numCartas / 2; i++) {
            imagenesSeleccionadas.push(imagenes[i % imagenes.length]);
        }

        const paresDeImagenes = [...imagenesSeleccionadas, ...imagenesSeleccionadas];

        for (let i = 0; i < paresDeImagenes.length; i++) {
            cartas.push({
                imagen: paresDeImagenes[i],
                estaVolteada: false,
                estaAcertada: false
            });
        }

        return cartas;
    }

    function barajarCartas(cartas) {
        cartas.sort(() => Math.random() - 0.5);
    }

    function generarTablero(cartas) {
        tablero.innerHTML = '';

        cartas.forEach((carta, index) => {
            const elementoCarta = document.createElement('div');
            elementoCarta.classList.add('carta');
            elementoCarta.dataset.index = index;

            const caraOculta = document.createElement('div');
            caraOculta.classList.add('cara-oculta');
            elementoCarta.appendChild(caraOculta);

            const imagen = document.createElement('img');
            imagen.src = carta.imagen;
            elementoCarta.appendChild(imagen);

            elementoCarta.addEventListener('click', () => voltearCarta(index));
            tablero.appendChild(elementoCarta);
        });
    }

    function voltearCarta(index) {
        if (bloqueado || cartas[index].estaVolteada || cartas[index].estaAcertada) return;

        cartas[index].estaVolteada = true;
        dibujarCarta(index);
        cartasVolteadas.push(index);

        if (cartasVolteadas.length === 2) {
            bloqueado = true;
            setTimeout(comprobarPareja, 1000);
        }
    }

    function dibujarCarta(index) {
        const elementoCarta = tablero.querySelector(`[data-index="${index}"]`);
        elementoCarta.classList.add('volteada');
    }

    function comprobarPareja() {
        const indexCarta1 = cartasVolteadas[0];
        const indexCarta2 = cartasVolteadas[1];
        cartasVolteadas = [];

        if (cartas[indexCarta1].imagen === cartas[indexCarta2].imagen) {
            acertarCarta(indexCarta1, indexCarta2);
        } else {
            fallarCarta(indexCarta1, indexCarta2);
        }

        bloqueado = false;
    }

    function acertarCarta(indexCarta1, indexCarta2) {
        cartas[indexCarta1].estaAcertada = true;
        cartas[indexCarta2].estaAcertada = true;
        puntos += 10;

        if (window.Utils && window.Utils.Game) {
            window.Utils.Game.addPoints(5);
        }

        actualizarDisplay();

        const elementoCarta1 = tablero.querySelector(`[data-index="${indexCarta1}"]`);
        const elementoCarta2 = tablero.querySelector(`[data-index="${indexCarta2}"]`);
        elementoCarta1.classList.add('acertada');
        elementoCarta2.classList.add('acertada');

        if (cartas.every(carta => carta.estaAcertada)) {
            setTimeout(subirNivel, 1000);
        }
    }

    function fallarCarta(indexCarta1, indexCarta2) {
        vidas--;
        actualizarDisplay();

        const elementoCarta1 = tablero.querySelector(`[data-index="${indexCarta1}"]`);
        const elementoCarta2 = tablero.querySelector(`[data-index="${indexCarta2}"]`);

        setTimeout(() => {
            cartas[indexCarta1].estaVolteada = false;
            cartas[indexCarta2].estaVolteada = false;
            elementoCarta1.classList.remove('volteada');
            elementoCarta2.classList.remove('volteada');
        }, 500);

        if (vidas === 0) {
            setTimeout(manejarDerrota, 1000);
        }
    }

    function subirNivel() {
        if (window.Utils && window.Utils.Game) {
            window.Utils.Game.addPoints(20);
        }

        nivel++;
        if (nivel > 5) {
            finalizarJuego(true);
            return;
        }
        vidas = 3;
        iniciarJuego();
    }

    function manejarDerrota() {
        finalizarJuego(false);
    }

    function finalizarJuego(victoria) {
        let nuevoRecord = false;

        if (puntos > puntuacionMaxima) {
            puntuacionMaxima = puntos;
            localStorage.setItem('puntuacionMaxima', puntuacionMaxima);
            nuevoRecord = true;
        }

        mensajeFinal.querySelector('h2').textContent = victoria ? '🎉 ¡Felicidades, has completado el juego! 🎉' : '💀 ¡PERDISTE! 💀';

        textoMaxPuntuacion.innerHTML = `
            Nivel alcanzado: <strong>${nivel}</strong><br>
            Puntuación máxima: <strong>${puntuacionMaxima}</strong>
            ${nuevoRecord ? '<span class="record-badge">¡NUEVO RÉCORD!</span>' : ''}
        `;
        puntuacionFinalDisplay.textContent = puntos;

        mensajeFinalOverlay.classList.remove('oculto');

        nivel = 1;
        vidas = 3;
        puntos = 0;
    }

    function actualizarDisplay() {
        nivelDisplay.textContent = nivel;
        vidasDisplay.textContent = vidas;
        puntosDisplay.textContent = puntos;
    }

    reiniciarJuegoBtn.addEventListener('click', () => {
        mensajeFinalOverlay.classList.add('oculto');
        iniciarJuego();
    });

    iniciarJuego();
});