const REWARDS = [
    {
        id: 'stickers',
        icon: '🏷️',
        title: 'Pack de Stickers',
        desc: 'Stickers exclusivos con temática ambiental de EcoSystem.',
        price: 100
    },
    {
        id: 'points',
        icon: '🎓',
        title: 'Puntos Extra',
        desc: '+1 Punto en tu próxima calificación de Biología.',
        price: 500
    },
    {
        id: 'combo',
        icon: '🍔',
        title: 'Hamburguesa y Café',
        desc: 'Un café frío y una hamburguesa en la cafetería escolar.',
        price: 800
    },
    {
        id: 'google',
        icon: '💳',
        title: 'Google Play $100',
        desc: 'Tarjeta de regalo digital de $100 MXN para Play Store.',
        price: 2000
    },
    {
        id: 'amazon',
        icon: '📦',
        title: 'Amazon $200',
        desc: 'Tarjeta de regalo digital de $200 MXN para Amazon México.',
        price: 5000
    }
];

function renderRewards() {
    const container = document.getElementById('rewards-container');
    const balance = Utils.Game.getPoints();

    container.innerHTML = REWARDS.map(reward => `
        <div class="reward-card">
            <div>
                <div class="reward-icon">${reward.icon}</div>
                <div class="reward-title">${reward.title}</div>
                <div class="reward-desc">${reward.desc}</div>
            </div>
            <div>
                <div class="reward-price">💎 ${reward.price} pts</div>
                <button class="btn-redeem" 
                    ${balance < reward.price ? 'disabled' : ''} 
                    onclick="handleRedeem('${reward.id}', ${reward.price}, '${reward.title}')">
                    ${balance < reward.price ? 'Insuficientes Puntos' : 'Canjear'}
                </button>
            </div>
        </div>
    `).join('');
}

function updateBalanceDisplay() {
    const balanceEl = document.getElementById('current-balance');
    if (balanceEl) {
        balanceEl.innerText = Utils.Game.getPoints().toLocaleString();
    }
}

function handleRedeem(id, price, title) {
    if (confirm(`¿Estás seguro que quieres canjear "${title}" por ${price} puntos?`)) {
        if (Utils.Game.deductPoints(price)) {
            showModal(title);
            updateBalanceDisplay();
            renderRewards();
        } else {
            Utils.Toast.show('No tienes suficientes puntos.', 'error');
        }
    }
}

function generateCode() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = '';
    for (let i = 0; i < 8; i++) {
        if (i === 4) code += '-';
        code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
}

function showModal(title) {
    const modal = document.getElementById('redeem-modal');
    document.getElementById('reward-code').innerText = generateCode();
    modal.style.display = 'flex';
}

function closeModal() {
    document.getElementById('redeem-modal').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', () => {
    updateBalanceDisplay();
    renderRewards();

    // Listen for points updates to refresh store balance
    window.addEventListener('pointsUpdated', () => {
        updateBalanceDisplay();
        renderRewards();
    });
});
