// GESTIÓN DE LA PÁGINA DE COMUNIDAD (IDEAS VERDES)
document.addEventListener("DOMContentLoaded", () => {
  const lista = document.getElementById("lista-ideas-guardadas");
  const form = document.getElementById("formulario-ideas");
  const input = document.getElementById("idea-texto");
  const borrarBtn = document.getElementById("borrar-ideas-btn");
  const contador = document.getElementById("contador-ideas");
  const feedback = document.getElementById("mensaje-feedback");

  const role = localStorage.getItem("role");

  const obtenerIdeas = () => JSON.parse(localStorage.getItem("ideasVerdes")) || [];
  const guardarIdeas = ideas => localStorage.setItem("ideasVerdes", JSON.stringify(ideas));
  const obtenerVotos = () => JSON.parse(localStorage.getItem("votosUsuario")) || {};
  const guardarVotos = votos => localStorage.setItem("votosUsuario", JSON.stringify(votos));

  // FUNCIONES PARA MOSTRAR Y GESTIONAR IDEAS
  function mostrarIdeas() {
    const ideas = obtenerIdeas();
    const votosUsuario = obtenerVotos();
    lista.innerHTML = "";
    if (ideas.length === 0) {
      lista.innerHTML = `<li style="border-left: 5px solid #ccc; background-color: rgba(255, 255, 255, 0.1);">No hay ideas aún. ¡Sé el primero en proponer una!</li>`;
      contador.textContent = `Total de ideas: 0`;
    } else {
      ideas.sort((a, b) => b.votos - a.votos || new Date(b.fecha) - new Date(a.fecha));
      ideas.forEach(idea => {
        const li = document.createElement("li");
        const fechaFormato = new Date(idea.fecha).toLocaleDateString("es-ES", {
          day: "numeric", month: "long", year: "numeric"
        });
        const haVotado = votosUsuario[idea.fecha];

        li.innerHTML = `
          <div>
            <p>${idea.texto}</p>
            <p><small>Enviada el ${fechaFormato}</small></p>
          </div>
          <div style="display: flex; align-items: center;">
            <span class="votos-contador">${idea.votos} votos</span>
            <button class="votar-btn btn btn-sm ${haVotado ? 'btn-outline' : ''}" data-fecha="${idea.fecha}" ${haVotado ? 'disabled' : ''}>
              ${haVotado ? 'Votado' : 'Votar'}
            </button>
          </div>
        `;
        lista.appendChild(li);
      });
      contador.textContent = `Total de ideas: ${ideas.length}`;
    }

    if (role !== 'admin') {
      borrarBtn.style.display = 'none';
    } else {
      borrarBtn.style.display = 'block';
    }
  }

  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault();
      const ideaTexto = input.value.trim();
      if (ideaTexto) {
        const nuevaIdea = {
          texto: ideaTexto,
          votos: 0,
          fecha: new Date().toISOString()
        };
        const ideas = obtenerIdeas();
        ideas.push(nuevaIdea);
        guardarIdeas(ideas);
        mostrarIdeas();
        input.value = "";

        feedback.textContent = '¡Idea enviada con éxito!';
        feedback.classList.remove('oculto', 'error');
        feedback.classList.add('exito');
        setTimeout(() => {
          feedback.classList.add('oculto');
          feedback.classList.remove('exito');
        }, 3000);

      } else {
        feedback.textContent = 'El campo no puede estar vacío.';
        feedback.classList.remove('oculto', 'exito');
        feedback.classList.add('error');
        setTimeout(() => {
          feedback.classList.add('oculto');
          feedback.classList.remove('error');
        }, 3000);
      }
    });
  }

  if (borrarBtn) {
    borrarBtn.addEventListener('click', () => {
      if (confirm("¿Estás seguro de que deseas borrar TODAS las ideas? Esta acción es irreversible.")) {
        localStorage.removeItem("ideasVerdes");
        localStorage.removeItem("votosUsuario");
        mostrarIdeas();
        feedback.textContent = '¡Todas las ideas han sido borradas!';
        feedback.classList.remove('oculto', 'error');
        feedback.classList.add('exito');
        setTimeout(() => {
          feedback.classList.add('oculto');
          feedback.classList.remove('exito');
        }, 3000);
      }
    });
  }

  lista.addEventListener("click", (e) => {
    if (e.target.classList.contains("votar-btn")) {
      const fecha = e.target.getAttribute("data-fecha");
      const ideas = obtenerIdeas();
      const ideaIndex = ideas.findIndex(idea => idea.fecha === fecha);

      if (ideaIndex !== -1) {
        ideas[ideaIndex].votos++;
        guardarIdeas(ideas);

        const votosUsuario = obtenerVotos();
        votosUsuario[fecha] = true;
        guardarVotos(votosUsuario);

        mostrarIdeas();
      }
    }
  });

  mostrarIdeas();

  // COMPONENTE: CARRUSEL DE TARJETAS (DÍAS IMPORTANTES)
  const contenedorTarjetas = document.querySelector('.contenedor-tarjetas');
  if (contenedorTarjetas) {
    const tarjetas = contenedorTarjetas.querySelectorAll('.tarjeta');
    let indiceActual = 0;
    const totalTarjetas = tarjetas.length;

    if (totalTarjetas > 0) {
      tarjetas.forEach((tarjeta, index) => {
        tarjeta.style.position = 'absolute';
        tarjeta.style.opacity = '0';
        tarjeta.style.zIndex = '1';
      });

      tarjetas[0].style.position = 'relative';
      tarjetas[0].style.opacity = '1';
      tarjetas[0].style.zIndex = '2';

      function mostrarSiguienteTarjeta() {
        const tarjetaAnterior = tarjetas[indiceActual];
        tarjetaAnterior.style.opacity = '0';
        tarjetaAnterior.style.zIndex = '1';

        indiceActual = (indiceActual + 1) % totalTarjetas;
        const tarjetaSiguiente = tarjetas[indiceActual];
        tarjetaSiguiente.style.position = 'relative';
        tarjetaSiguiente.style.opacity = '1';
        tarjetaSiguiente.style.zIndex = '2';

        setTimeout(() => {
          tarjetaAnterior.style.position = 'absolute';
        }, 5);
      }

      setInterval(mostrarSiguienteTarjeta, 4000);
    }
  }
});
