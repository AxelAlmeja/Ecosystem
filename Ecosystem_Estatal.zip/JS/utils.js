/**
 * UTILIDADES DE ECOSYSTEM
 * Maneja Autenticación, Seguridad y Notificaciones.
 */

const Utils = {
    // ==========================================
    // SEGURIDAD Y AUTENTICACIÓN
    // ==========================================
    Auth: {

        async hashPassword(password) {
            const msgBuffer = new TextEncoder().encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            return hashHex;
        },


        async register(userData) {
            const users = JSON.parse(localStorage.getItem('users')) || {};

            if (users[userData.username]) {
                return { success: false, message: 'El usuario ya existe.' };
            }


            const hashedPassword = await this.hashPassword(userData.password);

            users[userData.username] = {
                ...userData,
                password: hashedPassword
            };

            localStorage.setItem('users', JSON.stringify(users));
            return { success: true, message: 'Registro exitoso.' };
        },


        async login(username, password) {
            const users = JSON.parse(localStorage.getItem('users')) || {};
            const user = users[username];

            if (!user) {
                return { success: false, message: 'Usuario no encontrado.' };
            }



            const hashedPassword = await this.hashPassword(password);

            if (user.password === hashedPassword) {
                this.setSession(user);
                return { success: true, message: 'Bienvenido.', role: user.role };
            }

            else if (user.password === password) {
                user.password = hashedPassword;
                localStorage.setItem('users', JSON.stringify(users));
                this.setSession(user);
                return { success: true, message: 'Bienvenido (Seguridad Actualizada).', role: user.role };
            }

            return { success: false, message: 'Contraseña incorrecta.' };
        },

        setSession(user) {
            localStorage.setItem('loggedInUser', user.username);
            localStorage.setItem('role', user.role || 'user');
        },

        logout() {
            localStorage.removeItem('loggedInUser');
            localStorage.removeItem('role');
            window.location.href = 'index.html';
        },

        getCurrentUser() {
            const username = localStorage.getItem('loggedInUser');
            if (!username) return null;
            const users = JSON.parse(localStorage.getItem('users')) || {};
            return users[username];
        },

        isAuthenticated() {
            return !!localStorage.getItem('loggedInUser');
        },


        requireAuth(allowedRoles = []) {
            if (!this.isAuthenticated()) {
                window.location.href = 'index.html';
                return;
            }
            if (allowedRoles.length > 0) {
                const role = localStorage.getItem('role');
                if (!allowedRoles.includes(role)) {
                    Utils.Toast.show('No tienes permiso para acceder a esta página.', 'error');
                    setTimeout(() => window.location.href = 'portada.html', 2000);
                }
            }
        }
    },

    // ==========================================
    // NOTIFICACIONES (TOASTS)
    // ==========================================
    Toast: {
        container: null,

        init() {
            if (!document.getElementById('toast-container')) {
                this.container = document.createElement('div');
                this.container.id = 'toast-container';
                document.body.appendChild(this.container);
            } else {
                this.container = document.getElementById('toast-container');
            }
        },


        show(message, type = 'info') {
            this.init();

            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.innerText = message;


            const iconMock = type === 'success' ? '✔' : type === 'error' ? '✖' : 'ℹ';
            toast.innerHTML = `<span style="margin-right:8px; font-weight:bold;">${iconMock}</span> ${message}`;

            this.container.appendChild(toast);


            requestAnimationFrame(() => {
                toast.classList.add('show');
            });


            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => {
                    if (toast.parentNode) toast.parentNode.removeChild(toast);
                }, 300);
            }, 3000);
        }
    },



    // ==========================================
    // GAMIFICACIÓN
    // ==========================================
    Game: {
        getPoints() {
            return parseInt(localStorage.getItem('communityPoints')) || 0;
        },

        addPoints(amount) {
            let current = this.getPoints();
            current += amount;
            localStorage.setItem('communityPoints', current);


            Utils.Toast.show(`🏆 +${amount} Puntos!`, 'success');


            window.dispatchEvent(new Event('pointsUpdated'));
        },

        deductPoints(amount) {
            let current = this.getPoints();
            if (current >= amount) {
                current -= amount;
                localStorage.setItem('communityPoints', current);
                window.dispatchEvent(new Event('pointsUpdated'));
                return true;
            }
            return false;
        }
    },

    // ==========================================
    // GESTIÓN DE IU
    // ==========================================
    UI: {
        updateNavbar() {
            const user = Utils.Auth.getCurrentUser();
            const role = localStorage.getItem('role');
            const loginItem = document.getElementById('menu-login');
            const navList = document.querySelector('.nav-list');

            // 1. Manage Login/Logout Link
            if (user && loginItem) {
                // Si el usuario está autenticado, cambiar a botón de cerrar sesión
                loginItem.innerHTML = `<a href="#" class="nav-link" id="nav-logout">Cerrar Sesión</a>`;
                document.getElementById('nav-logout').addEventListener('click', (e) => {
                    e.preventDefault();
                    Utils.Auth.logout();
                });
            }

            // Gestionar Juegos vs Administración
            let juegosItem = document.getElementById('menu-juegos');

            if (!juegosItem && navList) {
                const li = document.createElement('li');
                li.id = 'menu-juegos';
                navList.appendChild(li);
                juegosItem = li;
            }

            if (juegosItem) {
                if (role === 'admin') {
                    juegosItem.innerHTML = `<a href="panel_admin.html" class="nav-link">Administración</a>`;
                } else {
                    juegosItem.innerHTML = `<a href="juegos.html" class="nav-link">Juegos</a>`;
                }

                // Agregar enlace a Recompensas si no existe
                if (!document.getElementById('menu-recompensas') && navList) {
                    const li = document.createElement('li');
                    li.id = 'menu-recompensas';
                    li.innerHTML = `<a href="recompensas.html" class="nav-link">Tienda</a>`;
                    juegosItem.insertAdjacentElement('afterend', li);
                }
            }
        }
    }
};

// Inicializar al cargar
document.addEventListener('DOMContentLoaded', () => {
    // Exponer a window para asegurar visibilidad
    window.Utils = Utils;

    Utils.Toast.init();
    Utils.UI.updateNavbar();

    console.log("✅ EcoSystem Utils Loaded & Ready");
});
