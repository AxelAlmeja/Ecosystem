// GESTIÓN DE LA PÁGINA DE PERFIL DE USUARIO
document.addEventListener('DOMContentLoaded', () => {
    const formulario = document.getElementById('formulario-perfil');
    const contenedorFormulario = document.getElementById('contenedor-formulario');
    const contenedorPerfil = document.getElementById('contenedor-perfil');
    const botonEditar = contenedorPerfil.querySelector('.boton-editar');
    const botonBorrar = document.getElementById('borrar-perfil-btn');
    const botonLogout = document.querySelector('.boton-logout');
    const botonCancelar = document.querySelector('.boton-cancelar');
    const adminBadge = document.getElementById('admin-badge');

    const loggedInUser = localStorage.getItem('loggedInUser');
    const role = localStorage.getItem('role');

    if (!loggedInUser) {
        window.location.href = 'index.html';
        return;
    }

    function mostrarFeedback(mensaje, tipo = 'success') {
        console.log(`[${tipo.toUpperCase()}]: ${mensaje}`);
        alert(mensaje);
    }

    // FUNCIONES DE CARGA Y RENDERIZADO
    function cargarDatosPerfil(userControlNumber) {
        const users = JSON.parse(localStorage.getItem('users')) || {};
        const perfilData = users[userControlNumber];

        if (perfilData) {
            document.getElementById('control-number-perfil').textContent = perfilData.username || 'N/A';
            document.getElementById('correo-perfil').textContent = perfilData.email || 'N/A';
            document.getElementById('numero-perfil').textContent = perfilData.numero || 'N/A';
            document.getElementById('foto-perfil').src = perfilData.imagen || 'placeholder.png';

            document.getElementById('control-number').value = perfilData.username || '';
            document.getElementById('correo').value = perfilData.email || '';
            document.getElementById('numero').value = perfilData.numero || '';
            document.getElementById('contraseña').value = '';
        } else {
            document.getElementById('control-number-perfil').textContent = userControlNumber || 'N/A';
            document.getElementById('foto-perfil').src = 'placeholder.png';
            mostrarFeedback('No se encontraron datos de perfil detallados. Por favor, edita tu perfil.', 'warning');
        }
    }

    function verificarRol() {
        if (role === 'admin' && adminBadge) {
            adminBadge.style.display = 'flex';
        } else if (adminBadge) {
            adminBadge.style.display = 'none';
        }
    }

    contenedorPerfil.style.display = 'flex';
    cargarDatosPerfil(loggedInUser);
    verificarRol();

    // GESTIÓN DEL FORMULARIO DE EDICIÓN
    if (formulario) {
        formulario.addEventListener('submit', function (e) {
            e.preventDefault();

            const users = JSON.parse(localStorage.getItem('users')) || {};
            let perfilData = users[loggedInUser] || { username: loggedInUser, role: role || 'user' };

            const correo = document.getElementById('correo').value;
            const password = document.getElementById('contraseña').value;
            const numero = document.getElementById('numero').value;
            const imagenInput = document.getElementById('imagen');

            perfilData.email = correo;
            if (password) {
                perfilData.password = password;
            }
            perfilData.numero = numero;

            function guardarYMostrar() {
                users[loggedInUser] = perfilData;
                localStorage.setItem('users', JSON.stringify(users));

                cargarDatosPerfil(loggedInUser);

                contenedorFormulario.style.display = 'none';
                contenedorPerfil.style.display = 'flex';

                mostrarFeedback('Perfil actualizado exitosamente.');
            }

            if (imagenInput.files && imagenInput.files[0]) {
                const reader = new FileReader();
                reader.onload = function (e) {
                    perfilData.imagen = e.target.result;
                    guardarYMostrar();
                }
                reader.readAsDataURL(imagenInput.files[0]);
            } else {
                guardarYMostrar();
            }
        });
    }

    if (botonEditar) {
        botonEditar.addEventListener('click', function () {
            cargarDatosPerfil(loggedInUser);
            contenedorFormulario.style.display = 'flex';
            contenedorPerfil.style.display = 'none';
        });
    }

    if (botonCancelar) {
        botonCancelar.addEventListener('click', function () {
            contenedorFormulario.style.display = 'none';
            contenedorPerfil.style.display = 'flex';
        });
    }

    function borrarPerfil() {
        if (confirm("¿Estás seguro de que deseas borrar *permanentemente* tus datos de perfil? Esta acción cerrará tu sesión.")) {
            let users = JSON.parse(localStorage.getItem('users')) || {};
            delete users[loggedInUser];
            localStorage.setItem('users', JSON.stringify(users));

            localStorage.removeItem('loggedInUser');
            localStorage.removeItem('role');

            mostrarFeedback('Datos de perfil y registro borrados. Redirigiendo a portada.', 'info');
            window.location.href = 'portada.html';
        }
    }

    if (botonBorrar) {
        botonBorrar.addEventListener('click', borrarPerfil);
    }

    // GESTIÓN DE CIERRE DE SESIÓN
    if (botonLogout) {
        botonLogout.addEventListener('click', function () {
            localStorage.removeItem('loggedInUser');
            localStorage.removeItem('role');

            mostrarFeedback('Sesión cerrada. Redirigiendo a la portada...', 'info');
            window.location.href = 'portada.html';
        });
    }
});
