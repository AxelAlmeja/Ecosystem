const especialidades = [
  "Programación",
  "Puericultura",
  "Servicios de Hospedaje",
  "Administración de Empresas",
  "Contabilidad",
  "Electrónica"
];

const asignaciones = [];

const NUM_ESPECIALIDADES = especialidades.length;
for (let dia = 1; dia <= 30; dia += 3) {
  const grupoIndex = Math.floor((dia - 1) / 3);
  const especialidad = especialidades[grupoIndex % NUM_ESPECIALIDADES];
  asignaciones.push({
    grupo: `Día ${dia}`,
    especialidad,
    fecha: `${dia} de Noviembre`
  });
}

const contenedorAsignaciones = document.getElementById("contenedorAsignaciones");

if (contenedorAsignaciones) {
  asignaciones.forEach(asignacion => {
    const div = document.createElement("div");
    div.classList.add("asignacion");
    div.innerHTML = `
        <p>Asignación de Riego: <strong>${asignacion.fecha}</strong></p>
        <p>Especialidad asignada: <strong>${asignacion.especialidad}</strong></p>
    `;
    contenedorAsignaciones.appendChild(div);
  });
}


const TASA_TAPAS_POR_KILO = 1000;

function obtenerRecolecciones() {
  const recoleccionesJSON = localStorage.getItem('recoleccionesTapas') || '[]';
  return JSON.parse(recoleccionesJSON);
}

function guardarRecolecciones(recolecciones) {
  localStorage.setItem('recoleccionesTapas', JSON.stringify(recolecciones));
}

function actualizarEstadisticas() {
  const recolecciones = obtenerRecolecciones();

  const totalTapas = recolecciones.reduce((sum, rec) => sum + rec.cantidad, 0);
  const elTotal = document.getElementById('totalTapas');
  if (elTotal) elTotal.textContent = totalTapas.toLocaleString('es-MX');

  const totalKilos = (totalTapas / TASA_TAPAS_POR_KILO).toFixed(2);
  const elKilos = document.getElementById('totalKilos');
  if (elKilos) elKilos.textContent = `${totalKilos} kg`;

  const conteoEspecialidades = recolecciones.reduce((acc, rec) => {
    acc[rec.especialidad] = (acc[rec.especialidad] || 0) + rec.cantidad;
    return acc;
  }, {});

  let especialidadLider = 'N/A';
  let maxTapas = -1;

  for (const [especialidad, tapas] of Object.entries(conteoEspecialidades)) {
    if (tapas > maxTapas) {
      maxTapas = tapas;
      especialidadLider = especialidad;
    }
  }
  const elLider = document.getElementById('especialidadLider');
  if (elLider) elLider.textContent = especialidadLider;

  const ultimaRecoleccion = recolecciones.length > 0
    ? new Date(recolecciones[recolecciones.length - 1].fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' })
    : 'N/A';
  const elUltima = document.getElementById('ultimaRecoleccion');
  if (elUltima) elUltima.textContent = ultimaRecoleccion;
}

// SECCIÓN: CARGA DE DATOS DESDE PANEL DE ADMINISTRACIÓN
function populateDropdowns() {
  const groups = JSON.parse(localStorage.getItem('admin_groups')) || [];
  const teachers = JSON.parse(localStorage.getItem('admin_teachers')) || [];

  const grupoSelect = document.getElementById('grupo');
  const docenteSelect = document.getElementById('docente');
  const turnoSelect = document.getElementById('turno');

  if (grupoSelect) {

    if (groups.length > 0) {
      grupoSelect.innerHTML = '<option value="">Selecciona un grupo</option>';
      groups.filter(g => g.active).forEach(g => {
        const opt = document.createElement('option');
        opt.value = g.name;
        opt.textContent = `${g.name} (${g.shift})`;
        opt.dataset.shift = g.shift;
        grupoSelect.appendChild(opt);
      });


      grupoSelect.addEventListener('change', () => {
        const selected = grupoSelect.options[grupoSelect.selectedIndex];
        if (selected && selected.dataset.shift && turnoSelect) {
          turnoSelect.value = selected.dataset.shift;
        }
      });
    }
  }

  if (docenteSelect) {
    if (teachers.length > 0) {
      docenteSelect.innerHTML = '<option value="">Selecciona un docente</option>';
      teachers.filter(t => t.active).forEach(t => {
        const opt = document.createElement('option');
        opt.value = t.name;
        opt.textContent = `${t.name} - ${t.area}`;
        docenteSelect.appendChild(opt);
      });
    }
  }
}


document.getElementById('formTapas').addEventListener('submit', function (e) {
  e.preventDefault();

  const especialidad = document.getElementById('especialidad').value;
  const grupo = document.getElementById('grupo').value;
  const turno = document.getElementById('turno').value;
  const docente = document.getElementById('docente') ? document.getElementById('docente').value : 'N/A';
  const cantidad = parseInt(document.getElementById('cantidad').value, 10);
  const evidenciaInput = document.getElementById('evidencia');

  if (cantidad <= 0) {
    Utils.Toast.show("La cantidad debe ser un número positivo.", "error");
    return;
  }

  if (!evidenciaInput.files || !evidenciaInput.files[0]) {
    Utils.Toast.show("Debes subir una foto de evidencia.", "error");
    return;
  }


  const reader = new FileReader();
  reader.onload = function (event) {
    const base64Image = event.target.result;

    const nuevaSolicitud = {
      id: Date.now(),
      especialidad,
      grupo,
      turno,
      docente,
      cantidad,
      image: base64Image,
      fecha: new Date().toISOString(),
      status: 'pending'
    };


    const pending = JSON.parse(localStorage.getItem('pending_records')) || [];
    pending.push(nuevaSolicitud);
    localStorage.setItem('pending_records', JSON.stringify(pending));


    const registroContenedor = document.getElementById("resultadoRegistro");
    registroContenedor.innerHTML = `
        <div class="asignacion" style="background-color: #fff3cd; border-left: 5px solid #ffc107; text-align: center;">
            <h2 style="color: #856404; margin-bottom: 10px;">¡Enviado a Revisión!</h2>
            <p>Tu registro de <strong>${cantidad} tapas</strong> ha sido enviado.</p>
            <p>Un administrador revisará la evidencia pronto.</p>
        </div>
      `;

    Utils.Toast.show('Registro enviado a revisión.', 'success');
    document.getElementById('formTapas').reset();
  };

  reader.readAsDataURL(evidenciaInput.files[0]);
});

const botonReiniciar = document.getElementById('reiniciarContadorBtn');
if (botonReiniciar) {
  botonReiniciar.addEventListener('click', () => {
    if (confirm("¿Estás seguro de que deseas reiniciar todos los contadores de tapas? Esta acción no se puede deshacer.")) {
      localStorage.removeItem('recoleccionesTapas');
      actualizarEstadisticas();
      Utils.Toast.show('Contadores Reiniciados', 'success');
    }
  });
}


document.addEventListener('DOMContentLoaded', () => {
  actualizarEstadisticas();
  populateDropdowns();
});