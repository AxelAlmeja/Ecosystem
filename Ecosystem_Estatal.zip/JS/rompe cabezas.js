const rompecabezas = document.getElementById("rompecabezas");
const zonaPiezas = document.getElementById("zona-piezas");
const movimientosTxt = document.getElementById("movimientos");
const infoPartida = document.getElementById("info-partida");
const pantallaInicio = document.getElementById("pantalla-inicio");
const zonaJuego = document.getElementById("zona-juego");
const mensajeFinal = document.getElementById("mensaje-final");
const textoTiempo = document.getElementById("tiempo");

const urlImagen = "IMG/rompecabezas.png";

let tamanoCuadricula = 3;
let tamanoPieza = 0;
let tamanoRompecabezas = 420;
let piezaActual = null;
let movimientos = 0;
let segundos = 0;
let intervaloTimer;

function formatearTiempo(s) {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const seg = (s % 60).toString().padStart(2, '0');
    return `${m}:${seg}`;
}

function cargarRecords() {
    const r3 = localStorage.getItem("mejor_3");
    const r4 = localStorage.getItem("mejor_4");
    document.getElementById("mejor-3").textContent = r3 ? formatearTiempo(parseInt(r3)) : "--:--";
    document.getElementById("mejor-4").textContent = r4 ? formatearTiempo(parseInt(r4)) : "--:--";
}

cargarRecords();

document.querySelectorAll("[data-dificultad]").forEach(btn => {
    btn.onclick = () => {
        tamanoCuadricula = parseInt(btn.dataset.dificultad);
        iniciarJuego();
    };
});

function iniciarJuego() {
    rompecabezas.innerHTML = "";
    zonaPiezas.innerHTML = "";
    movimientos = 0;
    segundos = 0;
    movimientosTxt.textContent = "0";
    textoTiempo.textContent = "00:00";

    pantallaInicio.classList.add("oculto");
    infoPartida.classList.remove("oculto");
    zonaJuego.classList.remove("oculto");

    tamanoPieza = tamanoRompecabezas / tamanoCuadricula;
    rompecabezas.style.width = tamanoRompecabezas + "px";
    rompecabezas.style.height = tamanoRompecabezas + "px";
    rompecabezas.style.gridTemplateColumns = `repeat(${tamanoCuadricula}, 1fr)`;

    crearCasillas();
    crearPiezas();

    clearInterval(intervaloTimer);
    intervaloTimer = setInterval(() => {
        segundos++;
        textoTiempo.textContent = formatearTiempo(segundos);
    }, 1000);
}

function crearCasillas() {
    for (let i = 0; i < tamanoCuadricula * tamanoCuadricula; i++) {
        const casilla = document.createElement("div");
        casilla.className = "casilla";
        casilla.dataset.indice = i;
        casilla.addEventListener("dragover", e => e.preventDefault());
        casilla.addEventListener("drop", function () {
            if (!piezaActual) return;
            if (this.firstChild) {
                const existente = this.firstChild;
                zonaPiezas.appendChild(existente);
                existente.style.position = "absolute";
                posicionarFuera(existente);
            }
            this.appendChild(piezaActual);
            piezaActual = null;
            movimientos++;
            movimientosTxt.textContent = movimientos;
            verificarVictoria();
        });
        rompecabezas.appendChild(casilla);
    }
}

function crearPiezas() {
    for (let i = 0; i < tamanoCuadricula * tamanoCuadricula; i++) {
        const pieza = document.createElement("div");
        pieza.className = "pieza";
        pieza.draggable = true;
        pieza.dataset.indiceCorrecto = i;

        /* CÁLCULO DE COORDENADAS */
        const x = (i % tamanoCuadricula) * tamanoPieza;
        const y = Math.floor(i / tamanoCuadricula) * tamanoPieza;

        pieza.style.width = tamanoPieza + "px";
        pieza.style.height = tamanoPieza + "px";
        pieza.style.backgroundImage = `url(${urlImagen})`;

        pieza.style.backgroundSize = `${tamanoRompecabezas}px ${tamanoRompecabezas}px`;

        pieza.style.backgroundPosition = `-${x}px -${y}px`;

        posicionarFuera(pieza);
        pieza.addEventListener("dragstart", () => {
            piezaActual = pieza;
        });

        zonaPiezas.appendChild(pieza);
    }
}

// POSICIONAR PIEZAS ALEATORIAMENTE FUERA DEL TABLERO
function posicionarFuera(p) {
    const anchoW = window.innerWidth;
    const altoW = window.innerHeight;
    const centroX = anchoW / 2;
    const centroY = altoW / 2;

    const margenTablero = (tamanoRompecabezas / 2) + 20; // Espacio mínimo desde el centro
    const ladoIzquierdo = Math.random() > 0.5;

    let posX;
    if (ladoIzquierdo) {
        // Aparece entre el borde izquierdo y el tablero (más cerca del centro)
        posX = (centroX - margenTablero - tamanoPieza - 100) + Math.random() * 100;
    } else {
        // Aparece entre el tablero y el borde derecho
        posX = (centroX + margenTablero) + Math.random() * 100;
    }

    // Aparecen centradas verticalmente respecto al tablero, no hasta abajo
    const posY = (centroY - (tamanoRompecabezas / 2)) + Math.random() * (tamanoRompecabezas - tamanoPieza);

    p.style.position = "absolute";
    p.style.left = posX + "px";
    p.style.top = posY + "px";
}

zonaJuego.addEventListener("dragover", e => e.preventDefault());
zonaJuego.addEventListener("drop", (e) => {
    if (piezaActual && (e.target === zonaJuego || e.target === zonaPiezas)) {
        const rect = zonaJuego.getBoundingClientRect();
        piezaActual.style.position = "absolute";
        piezaActual.style.left = (e.clientX - rect.left - tamanoPieza / 2) + "px";
        piezaActual.style.top = (e.clientY - rect.top - tamanoPieza / 2) + "px";
        zonaPiezas.appendChild(piezaActual);
        piezaActual = null;
    }
});

function verificarVictoria() {
    const casillas = document.querySelectorAll(".casilla");
    let ok = 0;
    casillas.forEach(s => {
        if (s.firstChild && s.firstChild.dataset.indiceCorrecto == s.dataset.indice) ok++;
    });

    if (ok === tamanoCuadricula * tamanoCuadricula) {
        clearInterval(intervaloTimer);
        const key = `mejor_${tamanoCuadricula}`;
        const actual = localStorage.getItem(key);
        if (!actual || segundos < parseInt(actual)) {
            localStorage.setItem(key, segundos);
            document.getElementById("nuevo-record").textContent = "⭐ ¡NUEVO RÉCORD! ⭐";
        }

        if (window.Utils && window.Utils.Game) {
            const points = tamanoCuadricula === 3 ? 30 : 50;
            window.Utils.Game.addPoints(points);
        }

        setTimeout(() => {
            document.getElementById("tiempo-final").textContent = `Tiempo: ${textoTiempo.textContent}`;
            mensajeFinal.classList.remove("oculto");
        }, 300);
    }
}