// GESTIÓN DEL CARRUSEL EN LA PÁGINA DE CONTACTO
document.addEventListener('DOMContentLoaded', function () {
  const tarjetas = document.querySelectorAll('.carousel-card');
  const btnAnterior = document.getElementById('anteriorBtn');
  const btnSiguiente = document.getElementById('siguienteBtn');
  let indiceActual = 0;

  function actualizarClasesCarrusel() {
    tarjetas.forEach((tarjeta, i) => {
      tarjeta.classList.remove('active', 'left', 'right', 'back');
      if (i === indiceActual) {
        tarjeta.classList.add('active');
      } else if (i === (indiceActual - 1 + tarjetas.length) % tarjetas.length) {
        tarjeta.classList.add('left');
      } else if (i === (indiceActual + 1) % tarjetas.length) {
        tarjeta.classList.add('right');
      } else {
        tarjeta.classList.add('back');
      }
    });
  }

  btnAnterior.addEventListener('click', () => {
    indiceActual = (indiceActual - 1 + tarjetas.length) % tarjetas.length;
    actualizarClasesCarrusel();
  });

  btnSiguiente.addEventListener('click', () => {
    indiceActual = (indiceActual + 1) % tarjetas.length;
    actualizarClasesCarrusel();
  });

  actualizarClasesCarrusel();
});