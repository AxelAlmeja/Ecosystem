// SELECCIÓN DE ELEMENTOS DEL DOM
const container = document.querySelector('.container');
const LoginLink = document.querySelector('.SignInLink');
const RegisterLink = document.querySelector('.SignUpLink');

const loginForm = document.querySelector('.form-box.Login form');
const loginUsernameInput = document.getElementById('login-username');
const loginPasswordInput = document.getElementById('login-password');

const registerForm = document.querySelector('.form-box.Register form');
const registerUsernameInput = document.getElementById('register-username');
const registerEmailInput = document.getElementById('register-email');
const registerPasswordInput = document.getElementById('register-password');

RegisterLink.addEventListener('click', () => {
    container.classList.add('active');
})

LoginLink.addEventListener('click', () => {
    container.classList.remove('active');
})

// GESTIÓN DE REGISTRO DE USUARIO
registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = registerUsernameInput.value.trim();
    const email = registerEmailInput.value.trim();
    const password = registerPasswordInput.value.trim();

    if (!username || !email || !password) {
        Utils.Toast.show('Por favor, completa todos los campos.', 'error');
        return;
    }

    if (!/^\d{14}$/.test(username)) {
        Utils.Toast.show('El número de control debe contener exactamente 14 dígitos.', 'error');
        return;
    }

    const result = await Utils.Auth.register({
        username: username,
        email: email,
        password: password,
        role: 'user'
    });

    if (result.success) {
        Utils.Toast.show('✅ Registro exitoso. Ahora puedes iniciar sesión.', 'success');
        registerForm.reset();
        container.classList.remove('active');
    } else {
        Utils.Toast.show('❌ Error: ' + result.message, 'error');
    }
});

// GESTIÓN DE INICIO DE SESIÓN DE USUARIO
loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = loginUsernameInput.value.trim();
    const password = loginPasswordInput.value.trim();

    if (!username || !password) {
        Utils.Toast.show('Por favor, ingresa tu No. control y Contraseña.', 'error');
        return;
    }

    if (!/^\d{14}$/.test(username)) {
        Utils.Toast.show('El número de control debe contener exactamente 14 dígitos.', 'error');
        return;
    }

    const result = await Utils.Auth.login(username, password);

    if (result.success) {
        Utils.Toast.show(result.message, 'success');
        loginForm.reset();
        setTimeout(() => {
            window.location.href = 'comunidad.html';
        }, 1500);
    } else {
        Utils.Toast.show('❌ ' + result.message, 'error');
    }
});

// GESTIÓN DE VISIBILIDAD DE CONTRASEÑA
document.addEventListener('DOMContentLoaded', () => {
    const togglePasswordIcons = document.querySelectorAll('.toggle-password');

    togglePasswordIcons.forEach(icon => {
        icon.setAttribute('color', '#2A5B5F');

        icon.addEventListener('click', () => {
            const targetId = icon.getAttribute('data-target');
            const passwordInput = document.getElementById(targetId);

            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.setAttribute('name', 'show');
            } else {
                passwordInput.type = 'password';
                icon.setAttribute('name', 'hide');
            }
        });
    });
});